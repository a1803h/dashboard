package tj.umed.hyperosdoctor;

import android.os.Build;
import java.util.*;

public final class DeviceContext {
    public final String wifi,hotspot,bluetooth,bluetoothConnection,audio;
    public final boolean xiaomi;
    public final boolean whatsappNetworkPriority,whatsappLowLatency,whatsappMemoryFreeze,whatsappDeviceIdle;

    private DeviceContext(String wifi,String hotspot,String bluetooth,String bluetoothConnection,String audio,boolean xiaomi,
                          boolean np,boolean ll,boolean mf,boolean di){
        this.wifi=wifi;this.hotspot=hotspot;this.bluetooth=bluetooth;this.bluetoothConnection=bluetoothConnection;this.audio=audio;this.xiaomi=xiaomi;
        this.whatsappNetworkPriority=np;this.whatsappLowLatency=ll;this.whatsappMemoryFreeze=mf;this.whatsappDeviceIdle=di;
    }

    public static DeviceContext capture(){
        String wifiRaw=out("cmd wifi status 2>/dev/null | head -n 8",8).toLowerCase(Locale.ROOT);
        String wifi=wifiRaw.contains("wifi is enabled")?"ON":wifiRaw.contains("wifi is disabled")?"OFF":"UNKNOWN";

        String apRaw=out("settings get global wifi_ap_state 2>/dev/null",5).trim();
        String hotspot;
        if("13".equals(apRaw)||"12".equals(apRaw))hotspot="ON";
        else if("11".equals(apRaw)||"10".equals(apRaw))hotspot="OFF";
        else if("14".equals(apRaw))hotspot="FAILED/OFF";
        else{
            String s=out("dumpsys wifi 2>/dev/null | grep -Eo 'num SoftApManagers:[0-9]+' | tail -n 1",10).trim();
            if(s.endsWith(":0"))hotspot="OFF";else if(s.matches(".*:[1-9][0-9]*$"))hotspot="ON";else hotspot="UNKNOWN";
        }

        String btRaw=out("settings get global bluetooth_on 2>/dev/null",5).trim();
        String bluetooth="1".equals(btRaw)?"ON":"0".equals(btRaw)?"OFF":"UNKNOWN";
        String btConn="N/A";
        if("ON".equals(bluetooth)){
            String c=out("dumpsys bluetooth_manager 2>/dev/null | grep -Eim1 'state=CONNECTED|STATE_CONNECTED|mConnectionState=2|connectionState=2|Connected: true'",10).trim();
            btConn=c.isEmpty()?"not detected":"YES";
        }

        String audioRaw=out("dumpsys audio 2>/dev/null | awk '/^[[:space:]]*players:/{f=1;next} /^[[:space:]]*ducked players/{f=0} f' | grep -m1 'state:started'",12).trim();
        String audio=audioRaw.isEmpty()?"IDLE":"PLAYING";

        boolean xiaomi=isXiaomi();
        String np=xiaomi?out("settings get system cloud_network_priority_whitelist 2>/dev/null",5):"";
        String ll=xiaomi?out("settings get system cloud_lowlatency_whitelist 2>/dev/null",5):"";
        String mf=xiaomi?out("settings get system cloud_memory_freeze_whitelist 2>/dev/null",5):"";
        String di=out("dumpsys deviceidle whitelist 2>/dev/null | grep -F 'com.whatsapp' | head -n 1",8);
        return new DeviceContext(wifi,hotspot,bluetooth,btConn,audio,xiaomi,containsPkg(np),containsPkg(ll),containsPkg(mf),!di.trim().isEmpty());
    }

    private static boolean isXiaomi(){
        String m=(Build.MANUFACTURER==null?"":Build.MANUFACTURER).toLowerCase(Locale.ROOT);
        String b=(Build.BRAND==null?"":Build.BRAND).toLowerCase(Locale.ROOT);
        return m.contains("xiaomi")||b.contains("xiaomi")||b.contains("redmi")||b.contains("poco");
    }
    private static boolean containsPkg(String raw){if(raw==null)return false;for(String x:raw.split("[,;:\\s]+"))if("com.whatsapp".equals(x.trim()))return true;return false;}
    private static String out(String cmd,int sec){CommandShell.Result r=CommandShell.exec(cmd,sec);return r.out==null?"":r.out;}
    private static String yn(boolean b){return b?"YES":"NO";}
    public String oneLine(){return "Wi-Fi "+wifi+"; hotspot "+hotspot+"; Bluetooth "+bluetooth+" (connected: "+bluetoothConnection+"); audio "+audio;}
    public String whitelistLine(){
        if(!xiaomi)return "Xiaomi cloud whitelist: N/A (non-Xiaomi device); DeviceIdle WhatsApp="+yn(whatsappDeviceIdle);
        return "WhatsApp Xiaomi whitelist: network_priority="+yn(whatsappNetworkPriority)+", lowlatency="+yn(whatsappLowLatency)+", memory_freeze="+yn(whatsappMemoryFreeze)+"; DeviceIdle="+yn(whatsappDeviceIdle);
    }
    public String toText(){return oneLine()+"\n"+whitelistLine()+"\n";}
}
