package tj.umed.hyperosdoctor;

import org.json.JSONObject;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

/** Detect logical failures masked by exit=0 on OEM dumpsys/sh commands. */
public final class ReportQuality {
    private static final String[] DUMPS={"batterystats_start.txt","batterystats_end.txt","meminfo.txt","cpuinfo.txt","netstats.txt","power.txt","alarms.txt","jobscheduler.txt","thermal.txt","activity_processes.txt","deviceidle.txt"};
    public final LinkedHashMap<String,String> statuses=new LinkedHashMap<>();
    public static ReportQuality inspect(File dir){ReportQuality q=new ReportQuality();for(String f:DUMPS)q.statuses.put(f,inspectOne(new File(dir,f)));return q;}
    static String inspectOne(File f){if(!f.isFile())return "UNAVAILABLE: file missing";
        try(BufferedReader b=new BufferedReader(new InputStreamReader(new FileInputStream(f),StandardCharsets.UTF_8))){
            String cmd=b.readLine();String exit=b.readLine();StringBuilder snippet=new StringBuilder();String s;int n=0,nonBlank=0;
            while((s=b.readLine())!=null&&n++<400){if(s.trim().isEmpty())continue;nonBlank++;if(snippet.length()<6500)snippet.append(s).append('\n');}
            String val=snippet.toString().toLowerCase(Locale.ROOT);
            if(val.contains("security exception")||val.contains("permission denial")||val.contains("requires android.permission")||val.contains("not allowed to")||val.contains("permission denied"))return "DENIED: permission/security exception in command output";
            if(val.contains("can't find service")||val.contains("service not found")||val.contains("unknown service"))return "UNAVAILABLE: service missing on this firmware";
            if(exit==null||!exit.trim().equals("exit=0"))return "FAILED: "+(exit==null?"missing exit status":exit);
            if(nonBlank==0)return "EMPTY: no usable data";
            if(f.getName().startsWith("batterystats_")&&!val.contains(",bt,"))return "UNAVAILABLE: checkin bt record missing";
            return "OK";
        }catch(Exception e){return "FAILED: "+e.getClass().getSimpleName();}
    }
    public String text(){StringBuilder s=new StringBuilder("=== Качество исходных данных ===\n");for(Map.Entry<String,String>e:statuses.entrySet())s.append(e.getKey()).append(": ").append(e.getValue()).append('\n');s.append("ADB-grant не гарантирует, что сервис доступен. Данные с DENIED/EMPTY не используются для оценки.\n");return s.toString();}
    public JSONObject toJson(){JSONObject o=new JSONObject();for(Map.Entry<String,String>e:statuses.entrySet())try{o.put(e.getKey(),e.getValue());}catch(Exception ignored){}return o;}
}
