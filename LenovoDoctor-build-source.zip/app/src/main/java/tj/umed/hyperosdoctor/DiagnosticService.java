package tj.umed.hyperosdoctor;

import android.app.*;
import android.content.*;
import android.os.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import org.json.JSONObject;

public class DiagnosticService extends Service {
    public static final String ACTION_START="tj.umed.hyperosdoctor.START", ACTION_STOP="tj.umed.hyperosdoctor.STOP", ACTION_TIMEOUT="tj.umed.hyperosdoctor.TIMEOUT", ACTION_UPDATE="tj.umed.hyperosdoctor.UPDATE", ACTION_DONE="tj.umed.hyperosdoctor.DONE";
    public static final String EXTRA_DURATION="duration", EXTRA_IDLE="idle";
    private static final String CHANNEL="diagnostic";

    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private volatile boolean stopRequested;
    private volatile String stopReason="duration_complete";
    private Analyzer analyzer;
    private EventTracker tracker;
    private File sessionDir;
    private long startedElapsed,targetDuration;
    private PendingIntent endAlarmPi,backupAlarmPi;
    private boolean exactEndAlarm,alarmClockBackupScheduled;
    private volatile Thread diagnosticThread;
    private volatile boolean alarmReceived;
    private volatile long alarmLatenessMs;
    private volatile String alarmSource="";
    private CommandShell.Access access;
    private final AtomicInteger earlyTimeoutIgnored=new AtomicInteger();

    private static final class DumpTask {
        final String name,cmd; final int timeout; final boolean rootOnly;
        DumpTask(String name,String cmd,int timeout){this(name,cmd,timeout,false);}
        DumpTask(String name,String cmd,int timeout,boolean rootOnly){this.name=name;this.cmd=cmd;this.timeout=timeout;this.rootOnly=rootOnly;}
    }

    @Override public void onCreate(){
        super.onCreate();
        NotificationManager nm=getSystemService(NotificationManager.class);
        if(Build.VERSION.SDK_INT>=26&&nm!=null)nm.createNotificationChannel(new NotificationChannel(CHANNEL,"Диагностика",NotificationManager.IMPORTANCE_LOW));
    }

    @Override public int onStartCommand(Intent intent,int flags,int id){
        if(intent==null)return START_NOT_STICKY;
        String action=intent.getAction();

        if(ACTION_STOP.equals(action)){
            stopReason="manual";
            stopRequested=true;
            Thread dt=diagnosticThread;if(dt!=null)dt.interrupt();
            prefs().edit().putString("stop_reason",stopReason).putString("phase","stopping").apply();
            if(prefs().getBoolean("running",false))broadcast(ACTION_UPDATE,"Мониторинг остановлен. Формирую отчёт…");
            return START_NOT_STICKY;
        }

        if(ACTION_TIMEOUT.equals(action)){
            if(!prefs().getBoolean("running",false))return START_NOT_STICKY;
            String phase=prefs().getString("phase","idle");
            long now=SystemClock.elapsedRealtime();
            long due=prefs().getLong("planned_end_elapsed",0);
            String source=intent.getStringExtra("alarm_source");if(source==null)source="unknown";
            if(!"monitoring".equals(phase))return START_NOT_STICKY;
            if(due>0&&now+1500L<due){
                int n=earlyTimeoutIgnored.incrementAndGet();
                prefs().edit().putInt("early_timeout_ignored",n).apply();
                scheduleEndAlarm(due,prefs().getBoolean("idle_mode",false));
                broadcast(ACTION_UPDATE,"Ранний системный alarm проигнорирован; тест продолжается.");
                return START_NOT_STICKY;
            }
            stopReason="timeout_alarm";
            alarmReceived=true;alarmLatenessMs=due>0?now-due:0;alarmSource=source;
            prefs().edit().putBoolean("alarm_received",true).putLong("alarm_lateness_ms",alarmLatenessMs).putString("alarm_source",alarmSource).apply();
            stopRequested=true;
            Thread dt=diagnosticThread;if(dt!=null)dt.interrupt();
            prefs().edit().putString("stop_reason",stopReason).putString("phase","stopping").apply();
            broadcast(ACTION_UPDATE,"Время теста истекло. Формирую отчёт…");
            return START_NOT_STICKY;
        }

        if(!ACTION_START.equals(action))return START_NOT_STICKY;
        if(isFreshRunning())return START_NOT_STICKY;
        cancelStaleEndAlarm();
        clearRunning();
        stopRequested=false; stopReason="duration_complete"; earlyTimeoutIgnored.set(0);alarmReceived=false;alarmLatenessMs=0;alarmSource="";alarmClockBackupScheduled=false;
        targetDuration=Math.max(60_000L,intent.getLongExtra(EXTRA_DURATION,300_000L));
        boolean idle=intent.getBooleanExtra(EXTRA_IDLE,false);
        startedElapsed=SystemClock.elapsedRealtime();
        startForeground(7,notificationRunning());
        prefs().edit().putBoolean("running",true).putString("phase","starting").putString("stop_reason","")
                .putInt("early_timeout_ignored",0).putLong("start_elapsed",startedElapsed).putLong("duration",targetDuration)
                .putLong("planned_end_elapsed",0).putLong("heartbeat",startedElapsed).putBoolean("idle_mode",idle).putBoolean("alarm_received",false).putLong("alarm_lateness_ms",0).putString("alarm_source","").apply();
        worker.submit(()->runDiagnostic(idle));
        return START_NOT_STICKY;
    }

    private void runDiagnostic(boolean idle){
        File base=null;
        diagnosticThread=Thread.currentThread();
        try{
            access=CommandShell.configure(this);
            File baseRoot=getExternalFilesDir(null);if(baseRoot==null)baseRoot=getFilesDir();
            base=new File(baseRoot,"sessions");base.mkdirs();
            sessionDir=new File(base,ReportWriter.newSessionName());sessionDir.mkdirs();
            analyzer=new Analyzer(idle);
            String accessText="access_mode="+access.shortName()+"\n"+access.details()+"\n"+access.permissionLine()+"\n";
            ReportWriter.text(new File(sessionDir,"README.txt"),"Lenovo Doctor 2.0 raw report\nNo data is uploaded automatically.\nUnavailable values mean NOT MEASURED, not zero.\nMode="+(idle?"idle":"normal")+"\n"+accessText);
            ReportWriter.text(new File(sessionDir,"access.txt"),accessText+"device="+Build.MANUFACTURER+" "+Build.MODEL+"\nandroid="+Build.VERSION.RELEASE+" sdk="+Build.VERSION.SDK_INT+"\n");

            broadcast(ACTION_UPDATE,"Подготавливаю тест… ["+access.shortName()+"]");
            captureStartRaw();
            DeviceContext startContext=DeviceContext.capture();
            ReportWriter.text(new File(sessionDir,"context_summary_start.txt"),startContext.toText());
            ReportWriter.dump(sessionDir,"batterystats_start.txt","dumpsys batterystats -c",12);
            DeviceVitals vitalsStart=DeviceVitals.capture(this);
            ReportWriter.text(new File(sessionDir,"battery_start.json"),vitalsStart.toJson().toString(2));

            startedElapsed=SystemClock.elapsedRealtime();
            long startedWall=System.currentTimeMillis();
            long startedUptime=SystemClock.uptimeMillis();
            long plannedEnd=startedElapsed+targetDuration;
            long plannedEndWall=startedWall+targetDuration;
            prefs().edit().putString("phase","monitoring").putLong("start_elapsed",startedElapsed).putLong("planned_end_elapsed",plannedEnd).putLong("heartbeat",startedElapsed).apply();
            broadcast(ACTION_UPDATE,(idle?"Idle-тест идёт. Экран можно выключить.":"Диагностика идёт. Пользуйся устройством обычно.")+" ["+access.shortName()+"]");
            exactEndAlarm=scheduleEndAlarm(plannedEnd,idle);
            if(CommandShell.canReadLogs()){
                try{tracker=new EventTracker(analyzer,sessionDir,startedWall,plannedEndWall);tracker.start();}
                catch(Exception e){ReportWriter.text(new File(sessionDir,"logcat_unavailable.txt"),e.toString()+"\n");tracker=null;}
            }else{
                ReportWriter.text(new File(sessionDir,"logcat_unavailable.txt"),"READ_LOGS not granted; live logcat tracking unavailable.\n");
            }

            File csv=new File(sessionDir,"process_samples.csv");
            ReportWriter.text(csv,"time_ms,process,cpu_pct,rss_mb\n");
            ProcSampler.Snapshot prev=null;
            int cores=Math.max(1,Runtime.getRuntime().availableProcessors());
            long lastHeartbeat=startedElapsed;
            long samplePeriodMs=idle?10_000L:5_000L;

            while(!stopRequested&&SystemClock.elapsedRealtime()-startedElapsed<targetDuration){
                ProcSampler.Snapshot s=ProcSampler.take();
                analyzer.accept(s);
                if(s!=null&&prev!=null)writeCsvDelta(csv,prev,s,cores);
                if(s!=null)prev=s;
                long now=SystemClock.elapsedRealtime();
                if(now-lastHeartbeat>=60_000L){prefs().edit().putLong("heartbeat",now).apply();lastHeartbeat=now;}
                long remaining=targetDuration-(now-startedElapsed);
                if(remaining<=0)break;
                sleep(Math.min(samplePeriodMs,Math.max(250,remaining)));
            }
            if(!stopRequested)stopReason="duration_complete";
            Thread.interrupted(); // clear interrupt used only to wake the monitor sleep

            long endElapsed=SystemClock.elapsedRealtime(),endUptime=SystemClock.uptimeMillis();
            long endedWall=System.currentTimeMillis();
            DeviceVitals vitalsEnd=DeviceVitals.capture(this);
            ReportWriter.text(new File(sessionDir,"battery_end.json"),vitalsEnd.toJson().toString(2));
            long stopLatenessMs=endElapsed-plannedEnd;
            boolean finalSnapshotUsed=false;
            if("manual".equals(stopReason)||stopLatenessMs<=5000L){
                ProcSampler.Snapshot fin=ProcSampler.take();
                if(fin!=null){analyzer.accept(fin);if(prev!=null)writeCsvDelta(csv,prev,fin,cores);prev=fin;finalSnapshotUsed=true;}
            }else{
                ReportWriter.text(new File(sessionDir,"process_final_snapshot.txt"),"SKIPPED: monitor ended "+stopLatenessMs+" ms after requested deadline; using it could mix post-window activity into CPU results.\n");
            }
            long actualMonitorMs=Math.max(0,endElapsed-startedElapsed);
            long uptimeMs=Math.max(0,endUptime-startedUptime);
            long suspendMs=Math.max(0,actualMonitorMs-uptimeMs);
            long analysisDurationMs=Math.max(1,Math.min(actualMonitorMs,targetDuration));
            if(tracker!=null)tracker.stop();
            cancelEndAlarm();

            prefs().edit().putString("phase","collecting").putString("stop_reason",stopReason).putLong("heartbeat",SystemClock.elapsedRealtime()).apply();
            broadcast(ACTION_UPDATE,"Мониторинг завершён. BatteryStats…");
            long collectionStart=SystemClock.elapsedRealtime();
            ReportWriter.dump(sessionDir,"batterystats_end.txt","dumpsys batterystats -c",12);

            broadcast(ACTION_UPDATE,"Снимаю контекст Wi‑Fi/Bluetooth/Audio…");
            DeviceContext endContext=DeviceContext.capture();
            ReportWriter.text(new File(sessionDir,"context_summary_end.txt"),endContext.toText());

            captureEndRawFast();
            UsageTimeline usage=UsageTimeline.read(this,startedWall,endedWall);
            ReportWriter.text(new File(sessionDir,"usage_events_summary.txt"),usage.report());
            ReportQuality quality=ReportQuality.inspect(sessionDir);
            ReportWriter.text(new File(sessionDir,"data_quality.txt"),quality.text()+"\n"+analyzer.qualityText());
            long collectionMs=Math.max(0,SystemClock.elapsedRealtime()-collectionStart);
            int early=earlyTimeoutIgnored.get();
            ReportWriter.text(new File(sessionDir,"timing.txt"),String.format(Locale.US,
                    "requested_ms=%d\nanalysis_ms=%d\nactual_monitor_ms=%d\nstop_lateness_ms=%d\nuptime_ms=%d\nsuspend_estimate_ms=%d\nsuspend_estimate_pct=%.2f\nreport_collection_ms=%d\nexact_end_alarm=%s\nalarm_clock_backup=%s\nalarm_received=%s\nalarm_lateness_ms=%d\nalarm_source=%s\nstop_reason=%s\nearly_timeout_ignored=%d\nfinal_process_snapshot_used=%s\naccess_mode=%s\n",
                    targetDuration,analysisDurationMs,actualMonitorMs,stopLatenessMs,uptimeMs,suspendMs,actualMonitorMs>0?100.0*suspendMs/actualMonitorMs:0,collectionMs,exactEndAlarm,alarmClockBackupScheduled,alarmReceived,alarmLatenessMs,alarmSource,stopReason,early,finalSnapshotUsed,access.shortName()));

            broadcast(ACTION_UPDATE,"Анализирую результаты…");
            BatteryStatsDelta bs=BatteryStatsDelta.from(new File(sessionDir,"batterystats_start.txt"),new File(sessionDir,"batterystats_end.txt"),cores);
            String summary=analyzer.makeSummary(analysisDurationMs,targetDuration,actualMonitorMs,collectionMs,uptimeMs,suspendMs,exactEndAlarm,alarmClockBackupScheduled,access.shortName(),stopReason,early,alarmReceived,alarmLatenessMs,alarmSource,finalSnapshotUsed)
                    +QuickChecks.build(sessionDir,idle,tracker,startContext,endContext)+bs.makeSummary()
                    +DeviceVitals.compare(vitalsStart,vitalsEnd)+usage.report()+"\n"+quality.text();
            ReportWriter.text(new File(sessionDir,"summary.txt"),summary);
            JSONObject json=analyzer.toJson(analysisDurationMs,targetDuration,actualMonitorMs,collectionMs,uptimeMs,suspendMs,exactEndAlarm,alarmClockBackupScheduled,access.shortName(),stopReason,early,alarmReceived,alarmLatenessMs,alarmSource,finalSnapshotUsed);
            json.put("battery_start",vitalsStart.toJson());json.put("battery_end",vitalsEnd.toJson());
            json.put("usage_events",usage.toJson());json.put("data_quality",quality.toJson());
            json.put("device_manufacturer",Build.MANUFACTURER);json.put("device_model",Build.MODEL);
            ReportWriter.text(new File(sessionDir,"summary.json"),json.toString(2));

            prefs().edit().putString("phase","packing").putLong("heartbeat",SystemClock.elapsedRealtime()).apply();
            broadcast(ACTION_UPDATE,"Упаковываю ZIP…");
            File zip=ReportWriter.zip(sessionDir);
            ReportWriter.deleteTree(sessionDir);
            ReportWriter.keepNewestZips(base,4);
            prefs().edit().putBoolean("running",false).putString("phase","idle").putString("summary",summary).putString("zip_path",zip.getAbsolutePath()).putString("file",zip.getName()).putLong("heartbeat",0).putLong("planned_end_elapsed",0).apply();
            broadcast(ACTION_DONE,summary);
            NotificationManager nm=getSystemService(NotificationManager.class);
            if(nm!=null)nm.notify(7,notificationDone("Готово. Открой Doctor и нажми «Сохранить ZIP-отчёт»"));
        }catch(Exception e){
            if(tracker!=null)tracker.stop();
            cancelEndAlarm();
            String msg="Ошибка диагностики: "+e.getClass().getSimpleName()+": "+String.valueOf(e.getMessage());
            String zipPath="";
            try{
                if(sessionDir!=null&&sessionDir.exists()){
                    ReportWriter.text(new File(sessionDir,"ERROR.txt"),msg+"\n");
                    File z=ReportWriter.zip(sessionDir);zipPath=z.getAbsolutePath();if(base!=null)ReportWriter.keepNewestZips(base,4);
                }
            }catch(Exception ignored){}
            prefs().edit().putBoolean("running",false).putString("phase","idle").putString("summary",msg).putString("zip_path",zipPath).putLong("heartbeat",0).putLong("planned_end_elapsed",0).apply();
            broadcast(ACTION_DONE,msg);
            NotificationManager nm=getSystemService(NotificationManager.class);if(nm!=null)nm.notify(7,notificationDone(msg));
        }finally{
            diagnosticThread=null;stopForeground(false);stopSelf();
        }
    }

    private void captureStartRaw(){
        ReportWriter.dump(sessionDir,"getprop.txt","getprop",10);
        ReportWriter.dump(sessionDir,"packages_uid.txt","cmd package list packages -U",10);
        if(CommandShell.isRoot()){
            ReportWriter.dump(sessionDir,"wakeup_sources_start.txt","cat /sys/kernel/debug/wakeup_sources 2>/dev/null || cat /sys/kernel/wakeup_reasons/last_resume_reason 2>/dev/null",8);
            ReportWriter.dump(sessionDir,"kernel_start.txt","dmesg 2>/dev/null | tail -n 5000",10);
        }else{
            ReportWriter.text(new File(sessionDir,"wakeup_sources_start.txt"),"UNAVAILABLE: kernel wakeup_sources requires root on this device.\n");
            ReportWriter.text(new File(sessionDir,"kernel_start.txt"),"UNAVAILABLE: dmesg requires root on this device.\n");
        }
        ReportWriter.dump(sessionDir,"context_start.txt",contextCmd(),12);
    }

    private void captureEndRawFast(){
        final DumpTask[] tasks=new DumpTask[]{
                new DumpTask("cpuinfo.txt","dumpsys cpuinfo",8),
                new DumpTask("meminfo.txt","dumpsys meminfo",12),
                new DumpTask("power.txt","dumpsys power",8),
                new DumpTask("alarms.txt","dumpsys alarm",10),
                new DumpTask("jobscheduler.txt","dumpsys jobscheduler",10),
                new DumpTask("thermal.txt","dumpsys thermalservice",8),
                new DumpTask("activity_processes.txt","dumpsys activity processes",10),
                new DumpTask("deviceidle.txt","dumpsys deviceidle",8),
                new DumpTask("netstats.txt","dumpsys netstats",10),
                new DumpTask("wakeup_sources_end.txt","cat /sys/kernel/debug/wakeup_sources 2>/dev/null || cat /sys/kernel/wakeup_reasons/last_resume_reason 2>/dev/null",8,true),
                new DumpTask("context_end.txt",contextCmd(),12),
                new DumpTask("kernel_end.txt","dmesg 2>/dev/null | tail -n 5000",10,true)
        };
        ExecutorService pool=Executors.newFixedThreadPool(3);AtomicInteger done=new AtomicInteger();
        for(DumpTask t:tasks){pool.submit(()->{try{
            if(t.rootOnly&&!CommandShell.isRoot())ReportWriter.text(new File(sessionDir,t.name),"UNAVAILABLE: requires root.\n");
            else ReportWriter.dump(sessionDir,t.name,t.cmd,t.timeout);
        }finally{int n=done.incrementAndGet();prefs().edit().putLong("heartbeat",SystemClock.elapsedRealtime()).apply();broadcast(ACTION_UPDATE,"Системные дампы: "+n+"/"+tasks.length);}});}
        pool.shutdown();
        try{if(!pool.awaitTermination(45,TimeUnit.SECONDS)){pool.shutdownNow();pool.awaitTermination(5,TimeUnit.SECONDS);}}catch(InterruptedException e){pool.shutdownNow();Thread.currentThread().interrupt();}
    }

    private String contextCmd(){
        return "echo '=== WIFI ==='; cmd wifi status 2>/dev/null; echo '=== HOTSPOT CURRENT ==='; echo -n 'wifi_ap_state='; settings get global wifi_ap_state 2>/dev/null; dumpsys wifi 2>/dev/null | grep -Eo 'num SoftApManagers:[0-9]+' | tail -n 5; echo '=== AUDIO CURRENT PLAYERS ==='; dumpsys audio 2>/dev/null | awk '/^[[:space:]]*players:/{f=1;next} /^[[:space:]]*ducked players/{f=0} f'; echo '=== BLUETOOTH ==='; echo -n 'bluetooth_on='; settings get global bluetooth_on 2>/dev/null; dumpsys bluetooth_manager 2>/dev/null | grep -Ei 'state=CONNECTED|STATE_CONNECTED|mConnectionState=2|connectionState=2|Connected: true' | head -n 30; echo '=== XIAOMI CLOUD WHITELISTS ==='; echo -n 'network_priority='; settings get system cloud_network_priority_whitelist 2>/dev/null; echo -n 'lowlatency='; settings get system cloud_lowlatency_whitelist 2>/dev/null; echo -n 'memory_freeze='; settings get system cloud_memory_freeze_whitelist 2>/dev/null; echo '=== DEVICEIDLE WHATSAPP ==='; dumpsys deviceidle whitelist 2>/dev/null | grep -F 'com.whatsapp' || true";
    }

    private PendingIntent makeEndAlarmPi(int requestCode,String source,int flags){
        Intent i=new Intent(this,DiagnosticService.class).setAction(ACTION_TIMEOUT).putExtra("alarm_source",source);
        return PendingIntent.getService(this,requestCode,i,flags|PendingIntent.FLAG_IMMUTABLE);
    }

    private PendingIntent makeAlarmShowPi(int flags){
        Intent i=new Intent(this,MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_CLEAR_TOP);
        return PendingIntent.getActivity(this,79,i,flags|PendingIntent.FLAG_IMMUTABLE);
    }

    private void cancelStaleEndAlarm(){
        try{
            AlarmManager am=getSystemService(AlarmManager.class);if(am==null)return;
            for(int rc:new int[]{77,78}){
                PendingIntent pi=makeEndAlarmPi(rc,rc==77?"exact":"alarm_clock",PendingIntent.FLAG_NO_CREATE);
                if(pi!=null){am.cancel(pi);pi.cancel();}
            }
        }catch(Exception ignored){}
    }

    private boolean scheduleEndAlarm(long triggerElapsed,boolean idle){
        try{
            AlarmManager am=getSystemService(AlarmManager.class);if(am==null)return false;
            endAlarmPi=makeEndAlarmPi(77,"exact",PendingIntent.FLAG_UPDATE_CURRENT);
            boolean exact=true;
            if(Build.VERSION.SDK_INT>=31&&!am.canScheduleExactAlarms()){
                if(CommandShell.isRoot())CommandShell.exec("cmd appops set "+getPackageName()+" SCHEDULE_EXACT_ALARM allow 2>/dev/null || true",5);
                exact=am.canScheduleExactAlarms();
            }
            if(Build.VERSION.SDK_INT>=23){
                if(exact)am.setExactAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP,triggerElapsed,endAlarmPi);
                else am.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP,triggerElapsed,endAlarmPi);
            }else am.setExact(AlarmManager.ELAPSED_REALTIME_WAKEUP,triggerElapsed,endAlarmPi);

            alarmClockBackupScheduled=false;
            if(idle&&Build.VERSION.SDK_INT>=21){
                try{
                    long wallTrigger=System.currentTimeMillis()+Math.max(1000L,triggerElapsed-SystemClock.elapsedRealtime());
                    backupAlarmPi=makeEndAlarmPi(78,"alarm_clock",PendingIntent.FLAG_UPDATE_CURRENT);
                    PendingIntent show=makeAlarmShowPi(PendingIntent.FLAG_UPDATE_CURRENT);
                    am.setAlarmClock(new AlarmManager.AlarmClockInfo(wallTrigger,show),backupAlarmPi);
                    alarmClockBackupScheduled=true;
                }catch(Exception ignored){alarmClockBackupScheduled=false;}
            }
            return exact;
        }catch(Exception e){return false;}
    }

    private void cancelEndAlarm(){
        try{
            AlarmManager am=getSystemService(AlarmManager.class);
            if(am!=null&&endAlarmPi!=null)am.cancel(endAlarmPi);
            if(am!=null&&backupAlarmPi!=null)am.cancel(backupAlarmPi);
        }catch(Exception ignored){}
        try{if(endAlarmPi!=null)endAlarmPi.cancel();}catch(Exception ignored){}
        try{if(backupAlarmPi!=null)backupAlarmPi.cancel();}catch(Exception ignored){}
        endAlarmPi=null;backupAlarmPi=null;
    }

    private void writeCsvDelta(File csv,ProcSampler.Snapshot old,ProcSampler.Snapshot now,int cores){
        long td=now.totalCpuTicks-old.totalCpuTicks;if(td<=0)return;StringBuilder sb=new StringBuilder();
        long t=Math.min(targetDuration,Math.max(0,SystemClock.elapsedRealtime()-startedElapsed));
        for(ProcSampler.ProcStat p:now.processes.values()){
            ProcSampler.ProcStat q=old.processes.get(p.pid);if(q==null||q.startTimeTicks!=p.startTimeTicks||!q.name.equals(p.name))continue;
            long d=p.cpuTicks-q.cpuTicks;if(d<=0)continue;double cpu=d*100.0*cores/td;if(cpu<0.15||cpu>cores*125.0)continue;
            sb.append(t).append(',').append(csvEscape(p.name)).append(',').append(String.format(Locale.US,"%.2f",cpu)).append(',').append(String.format(Locale.US,"%.1f",p.rssKb/1024.0)).append('\n');
        }
        ReportWriter.append(csv,sb.toString());
    }

    private Notification notificationRunning(){
        Intent open=new Intent(this,MainActivity.class);PendingIntent pi=PendingIntent.getActivity(this,0,open,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL):new Notification.Builder(this);
        return b.setContentTitle("Lenovo Doctor 2.0").setContentText("Диагностика идёт. Таймер — в приложении.").setSmallIcon(android.R.drawable.ic_menu_info_details).setContentIntent(pi).setOngoing(true).setOnlyAlertOnce(true).build();
    }
    private Notification notificationDone(String text){
        Intent open=new Intent(this,MainActivity.class);PendingIntent pi=PendingIntent.getActivity(this,0,open,PendingIntent.FLAG_IMMUTABLE|PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL):new Notification.Builder(this);
        return b.setContentTitle("Lenovo Doctor 2.0").setContentText(text).setSmallIcon(android.R.drawable.ic_menu_info_details).setContentIntent(pi).setOngoing(false).setOnlyAlertOnce(true).build();
    }

    private void broadcast(String a,String text){sendBroadcast(new Intent(a).setPackage(getPackageName()).putExtra("text",text));}
    private SharedPreferences prefs(){return getSharedPreferences("state",MODE_PRIVATE);}
    private boolean isFreshRunning(){
        if(!prefs().getBoolean("running",false))return false;
        long s=prefs().getLong("start_elapsed",0),d=prefs().getLong("duration",0),h=prefs().getLong("heartbeat",0),now=SystemClock.elapsedRealtime();
        if(s>0&&d>0&&now-s<=d+10*60_000L)return true;return h>0&&now-h<120_000L;
    }
    private void clearRunning(){if(!isFreshRunning())prefs().edit().putBoolean("running",false).putString("phase","idle").apply();}
    private static void sleep(long ms){try{Thread.sleep(ms);}catch(InterruptedException e){Thread.currentThread().interrupt();}}
    private static String csvEscape(String s){return '"'+s.replace("\"","\"\"")+'"';}
    @Override public android.os.IBinder onBind(Intent i){return null;}
    @Override public void onDestroy(){cancelEndAlarm();if(prefs().getBoolean("running",false))prefs().edit().putBoolean("running",false).putString("phase","idle").apply();worker.shutdownNow();super.onDestroy();}
}
