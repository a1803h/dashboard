package tj.umed.hyperosdoctor;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.*;

public final class BatteryStatsDelta {
    private static final class Bt { long startCount,batteryRealtime,batteryUptime,totalRealtime,totalUptime,startClock,screenOffRealtime,screenOffUptime; boolean ok; }
    private static final class Snap { Bt bt=new Bt(); Map<Integer,List<String>> pkgs=new HashMap<>(); Map<Integer,Long> cpuMs=new HashMap<>(); Map<Integer,Long> prCpuMs=new HashMap<>(); Map<Integer,Long> awlMs=new HashMap<>(); }
    public final boolean valid; public final String invalidReason; public final long windowMs,awakeMs,screenOffMs,screenOffAwakeMs; public final Map<Integer,Long> cpuDeltaMs,awlDeltaMs; public final Map<Integer,List<String>> pkgs; private final int cores;
    private BatteryStatsDelta(boolean v,String why,long w,long a,long so,long soa,Map<Integer,Long> c,Map<Integer,Long> wl,Map<Integer,List<String>> p,int cores){valid=v;invalidReason=why;windowMs=w;awakeMs=a;screenOffMs=so;screenOffAwakeMs=soa;cpuDeltaMs=c;awlDeltaMs=wl;pkgs=p;this.cores=cores;}
    public static BatteryStatsDelta from(File start,File end,int cores){try{Snap a=parse(start),b=parse(end);String bad=validate(a,b); if(bad!=null && bad.contains("bt-строки")){String details=explainUnavailable(start,end);if(details!=null)bad=details;}Map<Integer,List<String>> names=new HashMap<>(a.pkgs);for(Map.Entry<Integer,List<String>> e:b.pkgs.entrySet())names.put(e.getKey(),e.getValue());if(bad!=null)return new BatteryStatsDelta(false,bad,0,0,0,0,new HashMap<>(),new HashMap<>(),names,cores);long w=b.bt.totalRealtime-a.bt.totalRealtime,awake=b.bt.totalUptime-a.bt.totalUptime,so=b.bt.screenOffRealtime-a.bt.screenOffRealtime,soa=b.bt.screenOffUptime-a.bt.screenOffUptime;Map<Integer,Long> cpu=delta(a.cpuMs,b.cpuMs),wl=delta(a.awlMs,b.awlMs);cpu.entrySet().removeIf(e->e.getValue()<0||e.getValue()>w*cores*12L/10L);wl.entrySet().removeIf(e->e.getValue()<0||e.getValue()>w*12L/10L);return new BatteryStatsDelta(true,"",w,awake,so,soa,cpu,wl,names,cores);}catch(Exception e){return new BatteryStatsDelta(false,e.toString(),0,0,0,0,new HashMap<>(),new HashMap<>(),new HashMap<>(),cores);}}
    private static String explainUnavailable(File start,File end){
        for(File f:new File[]{start,end})try(BufferedReader br=new BufferedReader(new InputStreamReader(new FileInputStream(f),StandardCharsets.UTF_8))){
            String ln;int n=0;while((ln=br.readLine())!=null&&n++<100){String l=ln.toLowerCase(Locale.ROOT);
                if(l.contains("security exception")||l.contains("interact_across_users")||l.contains("permission denial"))
                    return "ZUI отклонил dumpsys batterystats: ограничение разрешений / INTERACT_ACROSS_USERS; UID-дельта недоступна";
                if(l.contains("can't find service"))return "служба batterystats отсутствует в системе";
            }
        }catch(Exception ignored){}
        return null;
    }
    private static String validate(Snap a,Snap b){if(!a.bt.ok||!b.bt.ok)return "нет корректной bt-строки";if(a.bt.startClock!=b.bt.startClock)return "BatteryStats был сброшен/перезапущен во время теста (startClock изменился)";if(a.bt.startCount!=b.bt.startCount)return "BatteryStats был сброшен/перезапущен во время теста (startCount изменился)";if(b.bt.totalRealtime<a.bt.totalRealtime||b.bt.totalUptime<a.bt.totalUptime||b.bt.batteryRealtime<a.bt.batteryRealtime||b.bt.screenOffRealtime<a.bt.screenOffRealtime)return "глобальные счётчики BatteryStats уменьшились";return null;}
    private static Map<Integer,Long> delta(Map<Integer,Long>a,Map<Integer,Long>b){Map<Integer,Long>r=new HashMap<>();for(Map.Entry<Integer,Long>e:b.entrySet()){long old=a.getOrDefault(e.getKey(),0L);long d=e.getValue()-old;if(d>=0)r.put(e.getKey(),d);}return r;}
    private static Snap parse(File f)throws IOException{Snap s=new Snap();try(BufferedReader br=new BufferedReader(new InputStreamReader(new FileInputStream(f),StandardCharsets.UTF_8))){String line;while((line=br.readLine())!=null){if(!line.startsWith("9,"))continue;String[] p=line.split(",",-1);if(p.length<4)continue;try{
                if(p.length>=6&&p[1].equals("0")&&p[2].equals("i")&&p[3].equals("uid")){int uid=Integer.parseInt(p[4]);s.pkgs.computeIfAbsent(uid,k->new ArrayList<>());if(!s.pkgs.get(uid).contains(p[5]))s.pkgs.get(uid).add(p[5]);continue;}
                if(!p[2].equals("l"))continue;int uid=Integer.parseInt(p[1]);String type=p[3];
                if(type.equals("bt")&&uid==0&&p.length>=12){s.bt.startCount=toL(p[4]);s.bt.batteryRealtime=toL(p[5]);s.bt.batteryUptime=toL(p[6]);s.bt.totalRealtime=toL(p[7]);s.bt.totalUptime=toL(p[8]);s.bt.startClock=toL(p[9]);s.bt.screenOffRealtime=toL(p[10]);s.bt.screenOffUptime=toL(p[11]);s.bt.ok=true;}
                else if(type.equals("cpu")&&p.length>=6){long user=toL(p[4]),sys=toL(p[5]);s.cpuMs.put(uid,Math.max(0,user)+Math.max(0,sys));}
                else if(type.equals("pr")&&p.length>=7){long user=toL(p[5]),sys=toL(p[6]);s.prCpuMs.put(uid,s.prCpuMs.getOrDefault(uid,0L)+Math.max(0,user)+Math.max(0,sys));}
                else if(type.equals("awl")&&p.length>=5){s.awlMs.put(uid,Math.max(0,toL(p[4])));}
            }catch(Exception ignored){}}}
        for(Map.Entry<Integer,Long> e:s.prCpuMs.entrySet())s.cpuMs.putIfAbsent(e.getKey(),e.getValue());
        return s;}
    private static long toL(String s){try{return Long.parseLong(s.trim());}catch(Exception e){return 0;}}
    public String makeSummary(){StringBuilder sb=new StringBuilder("\n=== BatteryStats delta ===\n");if(!valid){sb.append("Дельта UID НЕ ИСПОЛЬЗОВАНА: ").append(invalidReason).append(". Это защищает от ложных значений после сброса статистики.\n");return sb.toString();}double ds=windowMs>0?100.0*(1.0-awakeMs/(double)windowMs):0;sb.append(String.format(Locale.US,"Окно BatteryStats: %.1f с; CPU awake: %.1f с (%.1f%%), deep sleep ~%.1f%%\n",windowMs/1000.0,awakeMs/1000.0,100.0*awakeMs/windowMs,ds));if(screenOffMs>0){double d=100.0*(1.0-screenOffAwakeMs/(double)screenOffMs);sb.append(String.format(Locale.US,"Экран выкл.: %.1f с; CPU awake: %.1f с (%.1f%%), deep sleep ~%.1f%%\n",screenOffMs/1000.0,screenOffAwakeMs/1000.0,100.0*screenOffAwakeMs/screenOffMs,d));}
        sb.append("\nCPU по UID за валидное окно (Doctor исключён):\n");List<Map.Entry<Integer,Long>> c=sorted(cpuDeltaMs);int n=0;for(Map.Entry<Integer,Long>e:c){if(name(e.getKey()).contains("tj.umed.hyperosdoctor"))continue;if(e.getValue()<50)continue;sb.append(++n).append(". ").append(name(e.getKey())).append(String.format(Locale.US," — %.3f с CPU\n",e.getValue()/1000.0));if(n>=12)break;}if(n==0)sb.append("нет значимой активности\n");
        sb.append("\nAggregated partial wakelock delta:\n");List<Map.Entry<Integer,Long>> w=sorted(awlDeltaMs);n=0;for(Map.Entry<Integer,Long>e:w){if(e.getValue()<5)continue;sb.append(++n).append(". ").append(name(e.getKey())).append(String.format(Locale.US," — %.3f с\n",e.getValue()/1000.0));if(n>=10)break;}if(n==0)sb.append("нет значимых wakelock\n");return sb.toString();}
    private List<Map.Entry<Integer,Long>> sorted(Map<Integer,Long>m){List<Map.Entry<Integer,Long>>l=new ArrayList<>(m.entrySet());l.sort((a,b)->Long.compare(b.getValue(),a.getValue()));return l;}
    private String name(int uid){if(uid==0)return "UID 0 / kernel-root";if(uid==1000)return "UID 1000 / Android system (shared)";List<String>l=pkgs.get(uid);if(l==null||l.isEmpty())return "UID "+uid;if(l.size()==1)return l.get(0);StringBuilder b=new StringBuilder("UID "+uid+" [");for(int i=0;i<Math.min(3,l.size());i++){if(i>0)b.append(", ");b.append(l.get(i));}if(l.size()>3)b.append(", …");return b.append(']').toString();}
}
