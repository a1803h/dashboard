package tj.umed.hyperosdoctor;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import org.json.JSONObject;
import java.util.Locale;

/** Battery telemetry available to ordinary Android apps; no root/ADB assumptions. */
public final class DeviceVitals {
    public final long timestampMs;
    public final Integer levelPct, temperatureDeciC, voltageMv, chargeCounterUah;
    public final Long energyCounterNwh, currentNowUa;
    private DeviceVitals(long t,Integer pct,Integer temp,Integer voltage,Integer charge,Long energy,Long current){
        timestampMs=t;levelPct=pct;temperatureDeciC=temp;voltageMv=voltage;
        chargeCounterUah=charge;energyCounterNwh=energy;currentNowUa=current;
    }
    public static DeviceVitals capture(Context c){
        Intent b=c.registerReceiver(null,new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        BatteryManager m=(BatteryManager)c.getSystemService(Context.BATTERY_SERVICE);
        Integer level=null,temp=null,voltage=null,charge=null;Long energy=null,current=null;
        if(b!=null){
            int raw=b.getIntExtra(BatteryManager.EXTRA_LEVEL,-1),scale=b.getIntExtra(BatteryManager.EXTRA_SCALE,-1);
            if(raw>=0&&scale>0)level=(int)Math.round(raw*100.0/scale);
            temp=positiveOrZero(b.getIntExtra(BatteryManager.EXTRA_TEMPERATURE,-1));
            voltage=positiveOrZero(b.getIntExtra(BatteryManager.EXTRA_VOLTAGE,-1));
        }
        if(m!=null){
            try{int x=m.getIntProperty(BatteryManager.BATTERY_PROPERTY_CHARGE_COUNTER);if(x!=Integer.MIN_VALUE&&x>0)charge=x;}catch(Exception ignored){}
            try{long x=m.getLongProperty(BatteryManager.BATTERY_PROPERTY_ENERGY_COUNTER);if(x!=Long.MIN_VALUE&&x>0)energy=x;}catch(Exception ignored){}
            try{int x=m.getIntProperty(BatteryManager.BATTERY_PROPERTY_CURRENT_NOW);if(x!=Integer.MIN_VALUE)current=(long)x;}catch(Exception ignored){}
        }
        return new DeviceVitals(System.currentTimeMillis(),level,temp,voltage,charge,energy,current);
    }
    private static Integer positiveOrZero(int v){return v>=0?v:null;}
    public JSONObject toJson(){JSONObject j=new JSONObject();try{
        j.put("timestamp_ms",timestampMs);
        j.put("battery_level_pct",nullable(levelPct));j.put("temperature_deci_c",nullable(temperatureDeciC));
        j.put("voltage_mv",nullable(voltageMv));j.put("charge_counter_uah",nullable(chargeCounterUah));
        j.put("energy_counter_nwh",nullable(energyCounterNwh));j.put("current_now_ua",nullable(currentNowUa));
        }catch(Exception ignored){}return j;}
    private static Object nullable(Object v){return v==null?JSONObject.NULL:v;}
    public static String compare(DeviceVitals a,DeviceVitals b){StringBuilder s=new StringBuilder("\n=== Аккумулятор (Android BatteryManager) ===\n");
        if(a.levelPct!=null&&b.levelPct!=null)s.append("Заряд: ").append(a.levelPct).append("% → ").append(b.levelPct).append("% (грубое измерение с шагом ~1%).\n");
        else s.append("Процент заряда: недоступен.\n");
        if(a.chargeCounterUah!=null&&b.chargeCounterUah!=null)s.append(String.format(Locale.US,"Charge counter: %d → %d µAh (разница %+d µAh; точность зависит от прошивки).\n",a.chargeCounterUah,b.chargeCounterUah,b.chargeCounterUah-a.chargeCounterUah));
        else s.append("Charge counter: н/д.\n");
        if(a.energyCounterNwh!=null&&b.energyCounterNwh!=null)s.append(String.format(Locale.US,"Energy counter: %d → %d nWh.\n",a.energyCounterNwh,b.energyCounterNwh));
        else s.append("Energy counter: н/д.\n");
        if(a.temperatureDeciC!=null&&b.temperatureDeciC!=null)s.append(String.format(Locale.US,"Температура батареи: %.1f → %.1f °C.\n",a.temperatureDeciC/10.0,b.temperatureDeciC/10.0));
        s.append("Ток CURRENT_NOW — мгновенное значение, не доказательство расхода конкретного приложения.\n");return s.toString();
    }
}
