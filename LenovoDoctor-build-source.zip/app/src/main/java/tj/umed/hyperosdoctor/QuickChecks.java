package tj.umed.hyperosdoctor;

import java.io.*;
import java.nio.charset.StandardCharsets;

public final class QuickChecks {
    private QuickChecks(){}
    public static String build(File dir,boolean idle,EventTracker tracker,DeviceContext start,DeviceContext end){
        StringBuilder sb=new StringBuilder("\n=== Quick checks ===\n");
        File log=new File(dir,"logcat_system.txt");
        if(log.exists()){
            long thermal=count(log,"thermal_sample_event"),cnss=count(log,"cnss_pci_suspend"),lines=countLines(log);
            sb.append("logcat lines (diagnostic window): ").append(lines).append('\n');
            File post=new File(dir,"logcat_system_post_window.txt");
            long postLines=post.exists()?countLines(post):0;
            if(postLines>0)sb.append("logcat system lines after requested window (excluded): ").append(postLines).append('\n');
            sb.append("thermal_sample_event: ").append(thermal).append('\n');
            sb.append("cnss_pci_suspend в logcat: ").append(cnss).append('\n');
            if(tracker!=null)sb.append(tracker.contaminationSummary(idle));
        }else{
            sb.append("logcat: UNAVAILABLE (нужен ROOT или ADB-разрешение READ_LOGS)\n");
            if(idle)sb.append("Idle-контроль по событиям экрана недоступен без logcat events.\n");
        }
        sb.append("\nКонтекст START: ").append(start==null?"не получен":start.oneLine()).append('\n');
        if(start!=null)sb.append(start.whitelistLine()).append('\n');
        sb.append("Контекст END: ").append(end==null?"не получен":end.oneLine()).append('\n');
        if(end!=null)sb.append(end.whitelistLine()).append('\n');
        sb.append("Полные сырые данные также сохранены в context_start.txt/context_end.txt.\n");
        return sb.toString();
    }
    private static long count(File f,String needle){long n=0;try(BufferedReader br=new BufferedReader(new InputStreamReader(new FileInputStream(f),StandardCharsets.UTF_8))){String s;while((s=br.readLine())!=null)if(s.contains(needle))n++;}catch(Exception ignored){}return n;}
    private static long countLines(File f){long n=0;try(BufferedReader br=new BufferedReader(new FileReader(f))){while(br.readLine()!=null)n++;}catch(Exception ignored){}return n;}
}
