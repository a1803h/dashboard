package tj.umed.hyperosdoctor;

import android.app.AppOpsManager;
import android.app.usage.UsageEvents;
import android.app.usage.UsageStatsManager;
import android.content.Context;
import android.os.Process;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.*;

/** Timeline of visible app state events. These are not CPU, wakelock or energy readings. */
public final class UsageTimeline {
    public static final class Row {public final String packageName;int resumed,paused,foregroundServiceStarts,foregroundServiceStops;
        Row(String n){packageName=n;}
        JSONObject toJson(){JSONObject j=new JSONObject();try{j.put("package",packageName);j.put("activity_resumed",resumed);j.put("activity_paused_or_stopped",paused);j.put("fg_service_start",foregroundServiceStarts);j.put("fg_service_stop",foregroundServiceStops);}catch(Exception ignored){}return j;}
    }
    public final boolean available;public final String explanation;public final List<Row> rows;public final int eventCount;
    private UsageTimeline(boolean ok,String why,List<Row> r,int events){available=ok;explanation=why;rows=r;eventCount=events;}
    public static UsageTimeline read(Context c,long startWall,long endWall){
        AppOpsManager ops=(AppOpsManager)c.getSystemService(Context.APP_OPS_SERVICE);
        boolean granted=false;
        try{granted=ops!=null&&ops.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS,Process.myUid(),c.getPackageName())==AppOpsManager.MODE_ALLOWED;}catch(Exception ignored){}
        if(!granted)return new UsageTimeline(false,"GET_USAGE_STATS не разрешён",Collections.emptyList(),0);
        UsageStatsManager us=(UsageStatsManager)c.getSystemService(Context.USAGE_STATS_SERVICE);
        if(us==null)return new UsageTimeline(false,"UsageStatsManager отсутствует",Collections.emptyList(),0);
        Map<String,Row> m=new HashMap<>();int count=0;
        try{
            UsageEvents ev=us.queryEvents(startWall,Math.max(startWall+1,endWall));
            if(ev==null)return new UsageTimeline(false,"queryEvents вернул null",Collections.emptyList(),0);
            UsageEvents.Event e=new UsageEvents.Event();
            while(ev.hasNextEvent()&&count<50000){ev.getNextEvent(e);count++;
                if(e.getPackageName()==null)continue;
                int t=e.getEventType();
                if(t!=UsageEvents.Event.ACTIVITY_RESUMED&&t!=UsageEvents.Event.ACTIVITY_PAUSED&&t!=UsageEvents.Event.ACTIVITY_STOPPED&&t!=UsageEvents.Event.FOREGROUND_SERVICE_START&&t!=UsageEvents.Event.FOREGROUND_SERVICE_STOP)continue;
                Row r=m.computeIfAbsent(e.getPackageName(),Row::new);
                if(t==UsageEvents.Event.ACTIVITY_RESUMED)r.resumed++;
                else if(t==UsageEvents.Event.ACTIVITY_PAUSED||t==UsageEvents.Event.ACTIVITY_STOPPED)r.paused++;
                else if(t==UsageEvents.Event.FOREGROUND_SERVICE_START)r.foregroundServiceStarts++;
                else if(t==UsageEvents.Event.FOREGROUND_SERVICE_STOP)r.foregroundServiceStops++;
            }
            ArrayList<Row> rows=new ArrayList<>(m.values());rows.sort((a,b)->Integer.compare(b.resumed+b.foregroundServiceStarts,a.resumed+a.foregroundServiceStarts));
            return new UsageTimeline(true,count>=50000?"Достигнут лимит 50 000 событий":"",rows,count);
        }catch(Exception x){return new UsageTimeline(false,x.getClass().getSimpleName()+": "+x.getMessage(),Collections.emptyList(),0);}
    }
    public String report(){StringBuilder s=new StringBuilder("\n=== UsageEvents (НЕ CPU и НЕ энергопотребление) ===\n");
        if(!available)return s.append("Н/Д: ").append(explanation).append('\n').toString();
        s.append("Событий в Android UsageStats: ").append(eventCount).append("; активностей/сервисов: ").append(rows.size()).append(".\n");
        int n=0;for(Row r:rows){if(n++>=18)break;s.append(r.packageName).append(": activity resumed ").append(r.resumed).append(", paused/stopped ").append(r.paused).append(", FGS starts ").append(r.foregroundServiceStarts).append(", stops ").append(r.foregroundServiceStops).append('\n');}
        s.append("События отображают изменения состояния, а не расход батареи или время процессора.\n");return s.toString();
    }
    public JSONObject toJson(){JSONObject o=new JSONObject();try{o.put("available",available);o.put("reason",explanation);o.put("events",eventCount);JSONArray a=new JSONArray();for(Row r:rows)a.put(r.toJson());o.put("packages",a);}catch(Exception ignored){}return o;}
}
