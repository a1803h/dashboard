package tj.umed.hyperosdoctor;

import org.json.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/** Aggregates only verified observations. A denied CPU sample is never zero CPU. */
public final class Analyzer {
    public static final String SELF="tj.umed.hyperosdoctor";
    public static final class Agg {
        public final String name;long samples,cpuTicks,rssSumKb;double peakCpu;long peakRssKb;int starts,deaths,crashes,anrs,kills;
        Agg(String n){name=n;}
        double avgCpu(long durationMs){return durationMs<=0?0:(cpuTicks*100000.0/ProcSampler.CLK_TCK)/durationMs;}
        double avgRssMb(){return samples==0?0:(rssSumKb/(double)samples)/1024.0;}
        double peakRssMb(){return peakRssKb/1024.0;}
        double cpuSeconds(){return cpuTicks/(double)ProcSampler.CLK_TCK;}
    }
    private final Map<String,Agg> data=new ConcurrentHashMap<>();
    private final boolean idleMode;
    private final int cores=Math.max(1,Runtime.getRuntime().availableProcessors());
    private ProcSampler.Snapshot previous;
    private int snapshotsAttempted,snapshotsNonempty,snapshotPairsWithValidCpu;
    private int maxReadableProcesses;
    public Analyzer(boolean idle){idleMode=idle;}
    public synchronized void accept(ProcSampler.Snapshot now){
        snapshotsAttempted++;
        if(now==null||now.processes.isEmpty())return;
        snapshotsNonempty++;maxReadableProcesses=Math.max(maxReadableProcesses,now.processes.size());
        if(previous==null){previous=now;return;}
        long td=now.totalCpuTicks-previous.totalCpuTicks;
        if(td<=0){previous=now;return;}
        int validCpu=0;
        for(ProcSampler.ProcStat p:now.processes.values()){
            ProcSampler.ProcStat q=previous.processes.get(p.pid);
            if(q==null||q.startTimeTicks!=p.startTimeTicks||!norm(q.name).equals(norm(p.name)))continue;
            long d=p.cpuTicks-q.cpuTicks;if(d<0)continue;
            double instant=d*100.0*cores/td;
            if(instant<0||instant>cores*125.0)continue;
            validCpu++;
            Agg a=data.computeIfAbsent(norm(p.name),Agg::new);a.samples++;a.cpuTicks+=d;
            a.peakCpu=Math.max(a.peakCpu,instant);a.rssSumKb+=p.rssKb;a.peakRssKb=Math.max(a.peakRssKb,p.rssKb);
        }
        if(validCpu>0)snapshotPairsWithValidCpu++;
        previous=now;
    }
    public int snapshotAttempts(){return snapshotsAttempted;}
    public int snapshotNonempty(){return snapshotsNonempty;}
    public int pairsWithCpu(){return snapshotPairsWithValidCpu;}
    public int readableProcesses(){return maxReadableProcesses;}
    public boolean cpuAvailable(){return snapshotPairsWithValidCpu>0;}
    public void eventStart(String p){if(valid(p))data.computeIfAbsent(norm(p),Agg::new).starts++;}
    public void eventDeath(String p){if(valid(p))data.computeIfAbsent(norm(p),Agg::new).deaths++;}
    public void eventCrash(String p){if(valid(p))data.computeIfAbsent(norm(p),Agg::new).crashes++;}
    public void eventAnr(String p){if(valid(p))data.computeIfAbsent(norm(p),Agg::new).anrs++;}
    public void eventKill(String p){if(valid(p))data.computeIfAbsent(norm(p),Agg::new).kills++;}
    public double score(Agg a,long durationMs){
        double s=0;
        if(a.samples>=2){double avg=a.avgCpu(durationMs);s+=Math.min(42,avg*(idleMode?3.0:1.4));s+=Math.min(8,a.peakCpu*0.06);if(a.avgRssMb()>1000)s+=Math.min(6,(a.avgRssMb()-1000)/250.0);}
        s+=Math.min(40,a.crashes*20.0)+Math.min(45,a.anrs*30.0);
        if(a.starts>=5&&a.deaths>=3)s+=Math.min(20,(a.starts-3)*3.0);
        // A background restriction/cached-idle kill is NOT an app crash or battery bug.
        return Math.min(100,s);
    }
    public List<Agg> ranked(long durationMs){
        List<Agg> l=new ArrayList<>(data.values());
        l.removeIf(a->a.name.equals(SELF)||(a.samples<2&&a.crashes==0&&a.anrs==0&&a.starts<2&&a.deaths<2));
        l.sort((a,b)->Double.compare(score(b,durationMs),score(a,durationMs)));
        return l;
    }
    public Agg self(){return data.get(SELF);}
    public String qualityText(){return "Сэмплирование /proc: попыток "+snapshotsAttempted+", непустых "+snapshotsNonempty+", пар с CPU "+snapshotPairsWithValidCpu+", максимум процессов "+maxReadableProcesses+".\n"
            +(cpuAvailable()?"Часть процессов доступна; CPU приводится только для наблюдаемых процессов.\n":"Н/Д: CPU/RAM сторонних процессов не прочитаны. Android 14/ZUI ограничивает /proc; 0% НЕ означает отсутствие нагрузки.\n");}
    public String makeSummary(long durationMs,long requestedMs,long actualMonitorMs,long collectionMs,long uptimeMs,long suspendMs,boolean exactEndAlarm,boolean alarmClockBackup,String accessMode,String stopReason,int earlyTimeoutIgnored,boolean alarmReceived,long alarmLatenessMs,String alarmSource,boolean finalSnapshotUsed){
        StringBuilder sb=new StringBuilder();
        sb.append("Lenovo Doctor — результат\nВерсия: 2.0 Lenovo\nРежим: ").append(idleMode?"простой/экран выключен":"обычное использование").append('\n');
        sb.append("Доступ: ").append(accessMode).append("\nПричина завершения: ").append(stopReason).append('\n');
        if(earlyTimeoutIgnored>0)sb.append("Ранних alarm проигнорировано: ").append(earlyTimeoutIgnored).append('\n');
        sb.append(String.format(Locale.US,"Запрошенное окно: %.1f мин; фактически: %.1f мин; сбор дампов: %.1f с.\n",requestedMs/60000.0,actualMonitorMs/60000.0,collectionMs/1000.0));
        double suspend=actualMonitorMs>0?100.0*suspendMs/actualMonitorMs:0;
        sb.append(String.format(Locale.US,"Оценка системного suspend: %.1f с (%.1f%%); uptime: %.1f с.\n",suspendMs/1000.0,suspend,uptimeMs/1000.0));
        sb.append("Это разница elapsedRealtime - uptime, не аппаратное измерение стадий глубокого сна и не измерение расхода батареи.\n");
        sb.append("Exact alarm: ").append(exactEndAlarm?"YES":"FALLBACK").append("; AlarmClock backup: ").append(alarmClockBackup?"YES":"NO").append('\n');
        if(alarmReceived)sb.append("Alarm окончания: ").append(alarmSource).append(String.format(Locale.US,"; опоздание %+d мс\n",alarmLatenessMs));
        else sb.append("Alarm окончания: нет / ручное завершение\n");
        sb.append("Финальный снимок процессов: ").append(finalSnapshotUsed?"USED":"SKIPPED").append("\n");
        sb.append(qualityText()).append('\n');
        List<Agg> l=ranked(durationMs);int n=Math.min(15,l.size());
        if(n==0)sb.append("Подтверждённых событий crash/ANR/зацикливания в доступных источниках нет; недостаточные метрики не дают права считать устройство исправным.\n");
        for(int i=0;i<n;i++){
            Agg a=l.get(i);boolean proc=a.samples>=2;
            sb.append(i+1).append(". ").append(a.name).append(" — ").append(proc||a.crashes>0||a.anrs>0||a.starts>=5&&a.deaths>=3?(int)Math.round(score(a,durationMs))+"/100":"рейтинг н/д").append('\n');
            if(proc)sb.append(String.format(Locale.US,"   CPU avg %.2f%% (%.2f с CPU), peak %.1f%%; RAM avg %.0f MB, peak %.0f MB\n",a.avgCpu(durationMs),a.cpuSeconds(),a.peakCpu,a.avgRssMb(),a.peakRssMb()));
            else sb.append("   CPU/RAM: н/д (нет валидных /proc снимков).\n");
            sb.append("   starts ").append(a.starts).append(", deaths ").append(a.deaths).append(", crashes ").append(a.crashes).append(", ANR ").append(a.anrs).append(", kills ").append(a.kills).append('\n');
            String why=why(a,durationMs);if(!why.isEmpty())sb.append("   Основание: ").append(why).append('\n');sb.append('\n');
        }
        Agg me=self();if(me!=null&&me.samples>=2)sb.append(String.format(Locale.US,"CPU Doctor: %.2f%% avg, %.2f с (исключён из рейтинга).\n",me.avgCpu(durationMs),me.cpuSeconds()));
        sb.append("Принудительное завершение cached/background процесса НЕ равно аварийному сбою.\n");
        return sb.toString();
    }
    public JSONObject toJson(long durationMs,long requestedMs,long actualMonitorMs,long collectionMs,long uptimeMs,long suspendMs,boolean exactEndAlarm,boolean alarmClockBackup,String accessMode,String stopReason,int earlyTimeoutIgnored,boolean alarmReceived,long alarmLatenessMs,String alarmSource,boolean finalSnapshotUsed){
        JSONObject r=new JSONObject();try{
            r.put("version","2.0-lenovo");r.put("access_mode",accessMode);r.put("stop_reason",stopReason);r.put("early_timeout_ignored",earlyTimeoutIgnored);
            r.put("analysis_duration_ms",durationMs);r.put("requested_duration_ms",requestedMs);r.put("actual_monitor_duration_ms",actualMonitorMs);
            r.put("report_collection_ms",collectionMs);r.put("uptime_delta_ms",uptimeMs);r.put("suspend_estimate_ms",suspendMs);
            r.put("suspend_estimate_pct",actualMonitorMs>0?round1(100.0*suspendMs/actualMonitorMs):JSONObject.NULL);
            r.put("deep_sleep_estimate_pct",JSONObject.NULL); // not directly measurable without hardware counters
            r.put("exact_end_alarm",exactEndAlarm);r.put("alarm_clock_backup",alarmClockBackup);r.put("alarm_received",alarmReceived);r.put("alarm_lateness_ms",alarmLatenessMs);
            r.put("alarm_source",alarmSource);r.put("final_process_snapshot_used",finalSnapshotUsed);r.put("idle_mode",idleMode);r.put("cpu_cores",cores);
            r.put("cpu_data_available",cpuAvailable());r.put("proc_snapshot_attempts",snapshotsAttempted);r.put("proc_snapshot_nonempty",snapshotsNonempty);r.put("proc_snapshot_pairs_valid",snapshotPairsWithValidCpu);r.put("max_readable_processes",maxReadableProcesses);
            JSONArray arr=new JSONArray();for(Agg a:ranked(durationMs)){
                JSONObject o=new JSONObject();boolean proc=a.samples>=2;
                o.put("process",a.name);o.put("score",proc||a.crashes>0||a.anrs>0||a.starts>=5&&a.deaths>=3?Math.round(score(a,durationMs)):JSONObject.NULL);
                o.put("score_basis",proc?"proc_and_events":"events_only");o.put("avg_cpu_pct",proc?round1(a.avgCpu(durationMs)):JSONObject.NULL);
                o.put("cpu_seconds",proc?Math.round(a.cpuSeconds()*1000)/1000.0:JSONObject.NULL);o.put("peak_cpu_pct",proc?round1(a.peakCpu):JSONObject.NULL);
                o.put("avg_rss_mb",proc?Math.round(a.avgRssMb()):JSONObject.NULL);o.put("peak_rss_mb",proc?Math.round(a.peakRssMb()):JSONObject.NULL);
                o.put("starts",a.starts);o.put("deaths",a.deaths);o.put("crashes",a.crashes);o.put("anrs",a.anrs);o.put("kills",a.kills);o.put("reason",why(a,durationMs));arr.put(o);
            }r.put("processes",arr);
        }catch(Exception ignored){}return r;
    }
    private String why(Agg a,long d){List<String> w=new ArrayList<>();if(a.crashes>0)w.add("аварий: "+a.crashes);if(a.anrs>0)w.add("ANR: "+a.anrs);if(a.starts>=5&&a.deaths>=3)w.add("возможный цикл перезапусков");if(a.samples>=2){double lim=idleMode?1.5:7.0;if(a.avgCpu(d)>=lim)w.add(String.format(Locale.US,"высокий CPU %.2f%%",a.avgCpu(d)));if(a.peakCpu>=100&&a.cpuSeconds()>3)w.add("краткие пики CPU");}return String.join("; ",w);}
    private static String norm(String s){return s==null?"unknown":s.trim().replace("\u0000","");}
    private static boolean valid(String s){return s!=null&&!s.trim().isEmpty()&&!s.equals("null");}
    private static double round1(double x){return Math.round(x*10.0)/10.0;}
}
