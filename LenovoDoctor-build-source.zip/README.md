# Lenovo Doctor 2.0 (Android 14 / ZUI 16, TB371FC)

Based on HyperOS Doctor v1.9. The package ID remains `tj.umed.hyperosdoctor`, so
app data and the ADB permission setup continue to use the same identifier.

**This is a diagnostic app. It does not remove telemetry, debloat ZUI, change bootloader state, or modify the tablet's system.** All reports are saved locally. Use the in-app "Сохранить ZIP-отчёт" button to export.

## Fixed from the Lenovo TB371FC 2026-11-01 report

- A `dumpsys` command returning `exit=0` but `Security exception`, `Can't find service`, or an empty answer is not considered a successful measurement. `data_quality.txt` records the actual source status.
- A blocked `/proc` sampler no longer produces misleading `0% CPU`, `0 MB RAM`, or a clean bill of health. Numeric fields are JSON `null` if unavailable, and the text report says `н/д`.
- Background/cached process kills are counted as distinct **non-crash** events and no longer inflate risk scores by themselves.
- Added `battery_start.json`, `battery_end.json` via Android `BatteryManager` / `ACTION_BATTERY_CHANGED`, including optional charge and energy counters when exposed by the vendor.
- Added a bounded `UsageStatsManager.queryEvents` timeline (`usage_events_summary.txt`), clearly separated from CPU, wakelock and battery consumption metrics.
- Labels `elapsedRealtime - uptime` correctly as a **system suspend estimate**; it is not a measurement of SoC deep-sleep residency or energy consumption.
- BatteryStats-specific permission failures give a concrete error rather than a generic missing CSV record.
- Retains existing ADB, root, baseline modes, idle/active tests, event logcat, crash/ANR checks and ZIP export.

**Limitations:** ZUI 16 Android 14 may prevent third-party apps from reading other UIDs' CPU time and BatteryStats even with the DUMP, BATTERY_STATS, and READ_LOGS grants. Android cannot bypass these OS access controls without deeper system privileges. The app will show unmeasurable fields instead of fabricating results.

## ADB setup (optional, non-root)

Install the app, enable USB debugging, run on the PC:

```sh
adb shell pm grant tj.umed.hyperosdoctor android.permission.DUMP
adb shell pm grant tj.umed.hyperosdoctor android.permission.BATTERY_STATS
adb shell pm grant tj.umed.hyperosdoctor android.permission.READ_LOGS
adb shell appops set tj.umed.hyperosdoctor GET_USAGE_STATS allow
adb shell appops set tj.umed.hyperosdoctor SCHEDULE_EXACT_ALARM allow
```

Note: grant success does not imply every API or dumpsys command will actually work.
If Android refuses an upgrade because the APKs were signed with different debug keys,
remove the old app **after exporting any reports** and install the newly signed build.

## Build

Open as an Android Gradle project. Requirements: JDK 17, Android SDK Platform 35,
Android Gradle Plugin 8.7.3, Gradle 8.9. Build with `gradle assembleDebug`.
The GitHub Actions workflow in `.github/workflows/hyperosdoctor-build.yml` builds the APK.
Result: `app/build/outputs/apk/debug/app-debug.apk`.

For the Lenovo sleep test, switch off the screen and leave the tablet untouched for 10 or 30 minutes.
The foreground service plus the end alarm may themselves introduce a small measurement overhead.
