# Note 2 Doctor 1.1 — Android 7.1.2 / Samsung GT-N7100

Standalone read-only diagnostic tool for Resurrection Remix and other Android 7 ROMs. Built from HyperOS Doctor sources.

**Changes 1.1**
- Time the display-off interval with a SCREEN_ON / SCREEN_OFF receiver and elapsedRealtime/uptime; report suspend estimate *only for periods with the screen off*. A test with <60 seconds display-off is marked inconclusive.
- Replace concurrent, slow `dumpsys` captures with sequential 4–5 second `/proc` and `/sys` commands; exclude unreliable BatteryStats deltas rather than reporting zero usage. Root shell remains optional.
- Collect battery snapshots from Android's sticky BATTERY_CHANGED broadcast, with separate raw fuel gauge reads from sysfs (`batt_read_raw_soc`, `batt_read_adj_soc`, voltage etc., if supported). Read-only; does not change calibration or charge level.
- Avoid heavy `dumpsys wifi/bluetooth/audio` context probes; use framework APIs instead.
- Output `screen_timeline.csv`, `battery_samples.csv`, `battery_gauge_start/end.txt`, `timing.txt`, `summary.json`, `summary.txt` in the ZIP.

## Install and test
- Android min 7.1 (SDK 25), target SDK 25, four-core Exynos 4412 GT-N7100 recommended.
- This build uses a NEW package `tj.umed.note2doctor.n7100` to avoid Android's debug-signature mismatch with the previous APK; old and new can coexist. Uninstall the older version later if desired.
- Run 5 minutes while using the phone, then a separate 10-minute idle test, **turn the screen off immediately**. For battery validation, unplug charger and start at 40–80%, if safe for the battery.
- Share the resulting ZIP reports; ZIP may contain app names and system logs. No automatic upload, no internet permission, no automatic battery reset or debloating.
- Good deep sleep alone cannot prove ROM security or overall stability. Security patches from 2017 are obsolete.

## Build
Needs JDK 17, Android SDK 35 and Gradle 8.9. Run `gradle assembleDebug`. Also see `.github/workflows/hyperosdoctor-build.yml` for GitHub Actions. No third-party dependencies.
