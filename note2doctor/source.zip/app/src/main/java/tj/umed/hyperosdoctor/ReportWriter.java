package tj.umed.hyperosdoctor;

import android.content.*; import android.net.Uri; import android.os.Build; import android.provider.MediaStore;
import java.io.*; import java.nio.charset.StandardCharsets; import java.text.SimpleDateFormat; import java.util.*; import java.util.zip.*;

public final class ReportWriter {
    private ReportWriter(){}
    public static void text(File f,String s){try(Writer w=new OutputStreamWriter(new FileOutputStream(f),StandardCharsets.UTF_8)){w.write(s==null?"":s);}catch(Exception ignored){}}
    public static void append(File f,String s){try(Writer w=new OutputStreamWriter(new FileOutputStream(f,true),StandardCharsets.UTF_8)){w.write(s==null?"":s);}catch(Exception ignored){}}
    public static void dump(File dir,String name,String cmd,int timeout){CommandShell.Result r=CommandShell.exec(cmd,timeout);text(new File(dir,name),"$ "+cmd+"\nexit="+r.code+"\n\n"+r.out+(r.err.isEmpty()?"":"\n--- stderr ---\n"+r.err));}
    public static File zip(File dir)throws IOException{
        File z=new File(dir.getParentFile(),dir.getName()+".zip");
        File tmp=new File(dir.getParentFile(),dir.getName()+".zip.tmp");
        if(tmp.exists()&&!tmp.delete())throw new IOException("Cannot remove stale temp ZIP");
        try(ZipOutputStream o=new ZipOutputStream(new BufferedOutputStream(new FileOutputStream(tmp)))){
            File[]fs=dir.listFiles();if(fs!=null)for(File f:fs)if(f.isFile())add(o,f,f.getName());
        }
        if(z.exists()&&!z.delete()){tmp.delete();throw new IOException("Cannot replace old ZIP");}
        if(!tmp.renameTo(z)){tmp.delete();throw new IOException("Cannot finalize ZIP");}
        return z;
    }
    private static void add(ZipOutputStream z,File f,String n)throws IOException{z.putNextEntry(new ZipEntry(n));try(InputStream in=new BufferedInputStream(new FileInputStream(f))){byte[]b=new byte[16384];int x;while((x=in.read(b))>0)z.write(b,0,x);}z.closeEntry();}
    public static String newSessionName(){return "Note2Doctor_"+new SimpleDateFormat("yyyyMMdd_HHmmss",Locale.US).format(new Date());}
    public static void deleteTree(File f){if(f==null||!f.exists())return;if(f.isDirectory()){File[]x=f.listFiles();if(x!=null)for(File c:x)deleteTree(c);}f.delete();}
    public static void keepNewestZips(File base,int keep){File[]fs=base.listFiles((d,n)->n.endsWith(".zip"));if(fs==null||fs.length<=keep)return;Arrays.sort(fs,Comparator.comparingLong(File::lastModified).reversed());for(int i=keep;i<fs.length;i++)fs[i].delete();}
}
