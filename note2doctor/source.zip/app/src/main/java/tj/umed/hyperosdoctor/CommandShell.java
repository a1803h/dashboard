package tj.umed.hyperosdoctor;

import android.app.AppOpsManager;
import android.content.Context;
import android.content.pm.PackageManager;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.*;

public final class CommandShell {
    public enum Mode { ROOT, ADB, BASIC }

    public static final class Access {
        public final Mode mode;
        public final boolean root, dump, batteryStats, readLogs, usageStats;
        Access(Mode mode, boolean root, boolean dump, boolean batteryStats, boolean readLogs, boolean usageStats){
            this.mode=mode; this.root=root; this.dump=dump; this.batteryStats=batteryStats; this.readLogs=readLogs; this.usageStats=usageStats;
        }
        public boolean fullAdb(){ return dump && batteryStats && readLogs && usageStats; }
        public String shortName(){ return mode.name(); }
        public String details(){
            if(mode==Mode.ROOT) return "ROOT — полный доступ";
            if(mode==Mode.ADB) return "ADB — расширенный доступ; kernel/root-only данные могут быть недоступны";
            return "BASIC — ограниченный доступ";
        }
        public String permissionLine(){
            return "DUMP="+yn(dump)+", BATTERY_STATS="+yn(batteryStats)+", READ_LOGS="+yn(readLogs)+", USAGE_STATS="+yn(usageStats);
        }
        private static String yn(boolean b){ return b?"YES":"NO"; }
    }

    public static final class Result {
        public final int code; public final String out, err;
        Result(int code,String out,String err){this.code=code;this.out=out;this.err=err;}
        public boolean ok(){return code==0;}
    }

    private static volatile Access current = new Access(Mode.BASIC,false,false,false,false,false);
    private CommandShell(){}

    public static Access configure(Context c){ current=inspect(c); return current; }
    public static Access current(){ return current; }
    public static boolean isRoot(){ return current.root; }
    public static boolean canReadLogs(){ return current.root || current.readLogs; }
    public static boolean canDump(){ return current.root || current.dump; }
    public static boolean canBatteryStats(){ return current.root || (current.dump && current.batteryStats); }

    public static Access inspect(Context c){
        boolean root=hasRootRaw();
        boolean dump=granted(c,"android.permission.DUMP");
        boolean bs=granted(c,"android.permission.BATTERY_STATS");
        boolean logs=granted(c,"android.permission.READ_LOGS");
        boolean usage=hasUsageStats(c);
        Mode m=root?Mode.ROOT:((dump&&bs&&logs)?Mode.ADB:Mode.BASIC);
        return new Access(m,root,dump,bs,logs,usage);
    }

    private static boolean granted(Context c,String p){
        try{return c.checkSelfPermission(p)==PackageManager.PERMISSION_GRANTED;}catch(Exception e){return false;}
    }
    private static boolean hasUsageStats(Context c){
        try{
            AppOpsManager a=(AppOpsManager)c.getSystemService(Context.APP_OPS_SERVICE);
            if(a==null)return false;
            int mode=a.checkOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), c.getPackageName());
            return mode==AppOpsManager.MODE_ALLOWED;
        }catch(Exception e){return false;}
    }

    public static boolean hasRootRaw(){
        Process p=null;
        try{
            p=new ProcessBuilder("su","-c","id").start();
            if(!waitForCompat(p,5000)){p.destroy();return false;}
            String s=readAll(p.getInputStream());
            return p.exitValue()==0&&s.contains("uid=0");
        }catch(Exception e){if(p!=null)p.destroy();return false;}
    }

    public static Result exec(String command,int timeoutSeconds){
        return execInternal(command,timeoutSeconds,current.root);
    }

    private static Result execInternal(String command,int timeoutSeconds,boolean root){
        Process p=null; ExecutorService io=Executors.newFixedThreadPool(2);
        try{
            ProcessBuilder pb=root?new ProcessBuilder("su","-c",command):new ProcessBuilder("sh","-c",command);
            p=pb.start(); final Process q=p;
            Future<String> out=io.submit(()->readAll(q.getInputStream()));
            Future<String> err=io.submit(()->readAll(q.getErrorStream()));
            boolean done=waitForCompat(q,timeoutSeconds*1000L);
            if(!done){q.destroy();return new Result(124,safe(out),"timeout\n"+safe(err));}
            return new Result(q.exitValue(),safe(out),safe(err));
        }catch(Exception e){if(p!=null)p.destroy();return new Result(125,"",e.toString());}
        finally{io.shutdownNow();}
    }

    public static Process start(String command)throws IOException{
        ProcessBuilder pb=current.root?new ProcessBuilder("su","-c",command):new ProcessBuilder("sh","-c",command);
        return pb.redirectErrorStream(true).start();
    }

    // Compatible with Android 7.1's java.lang.Process: no Java 8 timeout overload needed.
    private static boolean waitForCompat(Process p,long timeoutMs)throws InterruptedException {
        long end=android.os.SystemClock.elapsedRealtime()+timeoutMs;
        while(android.os.SystemClock.elapsedRealtime()<end){
            try{p.exitValue();return true;}catch(IllegalThreadStateException ignored){}
            Thread.sleep(50);
        }
        try{p.exitValue();return true;}catch(IllegalThreadStateException ignored){return false;}
    }

    private static String readAll(InputStream in)throws IOException{
        ByteArrayOutputStream o=new ByteArrayOutputStream();byte[]b=new byte[8192];int n;
        while((n=in.read(b))>=0)o.write(b,0,n);
        return o.toString(StandardCharsets.UTF_8.name());
    }
    private static String safe(Future<String> f){try{return f.get(2,TimeUnit.SECONDS);}catch(Exception e){return "";}}
}
