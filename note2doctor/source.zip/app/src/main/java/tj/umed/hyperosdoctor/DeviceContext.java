package tj.umed.hyperosdoctor;

import android.bluetooth.BluetoothAdapter;
import android.content.Context;
import android.media.AudioManager;
import android.net.wifi.WifiManager;
import android.os.Build;
import java.util.Locale;

/** Fast Android framework status collection without expensive dumpsys calls. */
public final class DeviceContext {
    public final String wifi,hotspot,bluetooth,bluetoothConnection,audio;
    private DeviceContext(String w,String h,String b,String c,String a){wifi=w;hotspot=h;bluetooth=b;bluetoothConnection=c;audio=a;}
    public static DeviceContext capture(Context context){
        String wifi="UNKNOWN",bt="UNKNOWN",audio="UNKNOWN";
        try{WifiManager wm=(WifiManager)context.getApplicationContext().getSystemService(Context.WIFI_SERVICE);if(wm!=null)wifi=wm.isWifiEnabled()?"ON":"OFF";}catch(Exception ignored){}
        try{BluetoothAdapter a=BluetoothAdapter.getDefaultAdapter();if(a!=null)bt=a.isEnabled()?"ON":"OFF";else bt="UNAVAILABLE";}catch(Exception ignored){}
        try{AudioManager am=(AudioManager)context.getSystemService(Context.AUDIO_SERVICE);if(am!=null)audio=am.isMusicActive()?"PLAYING":"IDLE";}catch(Exception ignored){}
        return new DeviceContext(wifi,"UNKNOWN",bt,"UNKNOWN",audio);
    }
    public String oneLine(){return "Wi-Fi "+wifi+"; hotspot "+hotspot+"; Bluetooth "+bluetooth+" (connected: "+bluetoothConnection+"); audio "+audio;}
    public String whitelistLine(){return "Legacy ROM: Xiaomi-specific whitelists N/A; other app background restrictions not inferred.";}
    public String toText(){return oneLine()+"\n"+whitelistLine()+"\n";}
}
