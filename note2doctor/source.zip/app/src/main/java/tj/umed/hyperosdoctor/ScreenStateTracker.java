package tj.umed.hyperosdoctor;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.PowerManager;
import android.os.SystemClock;
import java.io.File;
import java.util.Locale;

/** Measures suspend time only while the display is off. Does not hold a wakelock. */
public final class ScreenStateTracker {
    private final Context context;
    private final File timeline;
    private final BroadcastReceiver receiver;
    private boolean registered;
    private boolean screenOn;
    private long lastElapsed,lastUptime,offElapsed,offUptime;
    private int offEvents,onEvents;
    private boolean finished;

    public ScreenStateTracker(Context context,File directory){
        this.context=context.getApplicationContext();
        timeline=new File(directory,"screen_timeline.csv");
        PowerManager pm=(PowerManager)this.context.getSystemService(Context.POWER_SERVICE);
        screenOn=pm==null||pm.isInteractive();
        lastElapsed=SystemClock.elapsedRealtime();lastUptime=SystemClock.uptimeMillis();
        ReportWriter.text(timeline,"elapsed_ms,uptime_ms,event,interactive\n"+lastElapsed+","+lastUptime+",START,"+screenOn+"\n");
        receiver=new BroadcastReceiver(){@Override public void onReceive(Context c,Intent intent){
            String a=intent.getAction();if(Intent.ACTION_SCREEN_OFF.equals(a))transition(false,"SCREEN_OFF");
            else if(Intent.ACTION_SCREEN_ON.equals(a))transition(true,"SCREEN_ON");
        }};
        IntentFilter f=new IntentFilter();f.addAction(Intent.ACTION_SCREEN_ON);f.addAction(Intent.ACTION_SCREEN_OFF);
        this.context.registerReceiver(receiver,f);registered=true;
    }

    private synchronized void transition(boolean next,String reason){
        if(finished||screenOn==next)return;
        accrue(SystemClock.elapsedRealtime(),SystemClock.uptimeMillis());
        screenOn=next;if(next)onEvents++;else offEvents++;
        ReportWriter.append(timeline,lastElapsed+","+lastUptime+","+reason+","+next+"\n");
    }
    private void accrue(long elapsed,long uptime){
        long dE=Math.max(0,elapsed-lastElapsed),dU=Math.max(0,uptime-lastUptime);
        if(!screenOn){offElapsed+=dE;offUptime+=Math.min(dE,dU);}
        lastElapsed=elapsed;lastUptime=uptime;
    }
    public synchronized void finish(long elapsed,long uptime){
        if(finished)return;
        accrue(elapsed,uptime);finished=true;
        ReportWriter.append(timeline,elapsed+","+uptime+",END,"+screenOn+"\n");
        if(registered){registered=false;try{context.unregisterReceiver(receiver);}catch(Exception ignored){}}
    }
    public void close(){finish(SystemClock.elapsedRealtime(),SystemClock.uptimeMillis());}
    public synchronized long offDurationMs(){return offElapsed;}
    public synchronized long offSuspendMs(){return Math.max(0,offElapsed-offUptime);}
    public synchronized int offEvents(){return offEvents;}
    public synchronized int onEvents(){return onEvents;}
    public synchronized String summary(){
        if(offElapsed<60_000)return "Экран выключен менее 60 секунд: оценка Deep Sleep при выключенном экране недостоверна.\n";
        return String.format(Locale.US,"Экран выключен: %.1f с; suspend при выключенном экране: %.1f с (%.1f%%); переходы off/on: %d/%d.\nЭто оценка по elapsedRealtime и uptime, не прямой замер энергии.\n",offElapsed/1000.0,offSuspendMs()/1000.0,100.0*offSuspendMs()/Math.max(1,offElapsed),offEvents,onEvents);
    }
}
