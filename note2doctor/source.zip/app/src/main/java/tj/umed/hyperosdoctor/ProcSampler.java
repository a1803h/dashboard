package tj.umed.hyperosdoctor;

import java.util.*;

public final class ProcSampler {
    public static final long CLK_TCK = 100L; // Android/Linux USER_HZ
    public static final class ProcStat {
        public final int pid; public final String name; public final long cpuTicks, rssKb, startTimeTicks;
        ProcStat(int pid,String name,long cpuTicks,long rssKb,long startTimeTicks){this.pid=pid;this.name=name;this.cpuTicks=cpuTicks;this.rssKb=rssKb;this.startTimeTicks=startTimeTicks;}
    }
    public static final class Snapshot {
        public final long totalCpuTicks; public final Map<Integer,ProcStat> processes; public final long pageSize;
        Snapshot(long totalCpuTicks,Map<Integer,ProcStat> processes,long pageSize){this.totalCpuTicks=totalCpuTicks;this.processes=processes;this.pageSize=pageSize;}
    }
    private static final String CMD="echo __PAGESIZE__; getconf PAGESIZE 2>/dev/null || echo 4096; echo __CPU__; head -n 1 /proc/stat; echo __PS__; ps -A -o PID,ARGS 2>/dev/null || ps 2>/dev/null; echo __STAT__; cat /proc/[0-9]*/stat 2>/dev/null";
    public static Snapshot take(){ CommandShell.Result r=CommandShell.exec(CMD,12); if(!r.ok()&&r.out.isEmpty())return null; return parse(r.out); }
    static Snapshot parse(String text){
        String sec=""; long total=0,page=4096; Map<Integer,String> names=new HashMap<>(); List<String> stats=new ArrayList<>();
        for(String raw:text.split("\\r?\\n")){
            String line=raw.trim();
            if(line.equals("__PAGESIZE__")||line.equals("__CPU__")||line.equals("__PS__")||line.equals("__STAT__")){sec=line;continue;}
            if(line.isEmpty())continue;
            if(sec.equals("__PAGESIZE__")){ try{page=Long.parseLong(line);}catch(Exception ignored){} }
            else if(sec.equals("__CPU__")&&line.startsWith("cpu ")){String[] p=line.split("\\s+");for(int i=1;i<p.length;i++)try{total+=Long.parseLong(p[i]);}catch(Exception ignored){}}
            else if(sec.equals("__PS__")){
                if(line.toUpperCase(Locale.ROOT).startsWith("PID "))continue; int sp=firstWs(line); if(sp>0)try{int pid=Integer.parseInt(line.substring(0,sp).trim());String a=line.substring(sp).trim();if(!a.isEmpty()){int x=firstWs(a);names.put(pid,x>0?a.substring(0,x):a);}}catch(Exception ignored){}
            } else if(sec.equals("__STAT__")) stats.add(raw);
        }
        Map<Integer,ProcStat> out=new HashMap<>();
        for(String line:stats){int lp=line.indexOf('('),rp=line.lastIndexOf(')');if(lp<=0||rp<=lp)continue;try{
            int pid=Integer.parseInt(line.substring(0,lp).trim()); String comm=line.substring(lp+1,rp); String[] f=line.substring(rp+1).trim().split("\\s+"); if(f.length<22)continue;
            long ut=Long.parseLong(f[11]), st=Long.parseLong(f[12]), start=Long.parseLong(f[19]), rssPages=Long.parseLong(f[21]);
            long rssKb=Math.max(0,rssPages*page/1024L); String name=names.get(pid); if(name==null||name.isEmpty())name=comm;
            out.put(pid,new ProcStat(pid,name,ut+st,rssKb,start));
        }catch(Exception ignored){}}
        return new Snapshot(total,out,page);
    }
    private static int firstWs(String s){for(int i=0;i<s.length();i++)if(Character.isWhitespace(s.charAt(i)))return i;return -1;}
}
