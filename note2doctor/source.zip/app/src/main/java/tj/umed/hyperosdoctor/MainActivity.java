package tj.umed.hyperosdoctor;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.*;
import android.text.TextUtils;
import android.view.*;
import android.widget.*;
import java.io.File;
import java.util.Locale;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    private TextView accessStatus,state,timer,result,adbHelp;
    private Button normalBtn,idleBtn,stopBtn,saveBtn,copyAdbBtn;
    private final ExecutorService pool=Executors.newSingleThreadExecutor();
    private final Handler main=new Handler(Looper.getMainLooper());

    private static final String ADB_COMMANDS=
            "adb shell pm grant tj.umed.note2doctor.n7100 android.permission.DUMP\n"+
            "adb shell pm grant tj.umed.note2doctor.n7100 android.permission.BATTERY_STATS\n"+
            "adb shell pm grant tj.umed.note2doctor.n7100 android.permission.READ_LOGS\n"+
            "adb shell appops set tj.umed.note2doctor.n7100 GET_USAGE_STATS allow";

    private final BroadcastReceiver receiver=new BroadcastReceiver(){@Override public void onReceive(Context c,Intent i){
        String t=i.getStringExtra("text");
        if(DiagnosticService.ACTION_UPDATE.equals(i.getAction())){if(t!=null)state.setText(t);refreshButtons();}
        else if(DiagnosticService.ACTION_DONE.equals(i.getAction())){if(t!=null)result.setText(t);state.setText("Готово");refreshButtons();}
    }};
    private final Runnable tick=new Runnable(){@Override public void run(){syncStoredState();main.postDelayed(this,1000);}};

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);buildUi();
        if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},20);
        checkAccess();result.setText(loadSummary());refreshButtons();main.post(tick);
    }
    @Override protected void onResume(){super.onResume();syncStoredState();checkAccess();}
    @Override protected void onStart(){super.onStart();IntentFilter f=new IntentFilter();f.addAction(DiagnosticService.ACTION_UPDATE);f.addAction(DiagnosticService.ACTION_DONE);if(Build.VERSION.SDK_INT>=33)registerReceiver(receiver,f,Context.RECEIVER_NOT_EXPORTED);else registerReceiver(receiver,f);syncStoredState();}
    @Override protected void onStop(){super.onStop();try{unregisterReceiver(receiver);}catch(Exception ignored){}}
    @Override protected void onDestroy(){main.removeCallbacks(tick);pool.shutdownNow();super.onDestroy();}

    private void buildUi(){
        ScrollView scroll=new ScrollView(this);LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(20),dp(18),dp(20),dp(30));scroll.addView(box);
        TextView title=tv("Note 2 Doctor 1.1",28,true);box.addView(title);
        TextView sub=tv("Для Android 7.1.2: батарея (процент, напряжение, fuel gauge), Deep Sleep после выключения экрана, Exynos, CPU/RAM, crash/ANR и logcat. Поддерживает ROOT, ADB и BASIC режимы.",15,false);sub.setTextColor(Color.DKGRAY);sub.setPadding(0,dp(6),0,dp(16));box.addView(sub);
        accessStatus=card("Доступ: проверяю…");state=card("Готов к диагностике");timer=card("Таймер: 00:00");box.addView(accessStatus);box.addView(state);box.addView(timer);

        TextView ah=tv("ADB-доступ для устройства без root",19,true);ah.setPadding(0,dp(16),0,dp(6));box.addView(ah);
        TextView ad=tv("На Note 2 ROOT желателен, но не обязателен. Без ROOT можно выдать разрешения через ADB с компьютера.",13,false);ad.setTextColor(Color.DKGRAY);box.addView(ad);
        adbHelp=tv(ADB_COMMANDS,12,false);adbHelp.setTextIsSelectable(true);adbHelp.setTypeface(android.graphics.Typeface.MONOSPACE);adbHelp.setPadding(dp(12),dp(10),dp(12),dp(10));adbHelp.setBackgroundColor(Color.rgb(245,245,245));box.addView(adbHelp,new LinearLayout.LayoutParams(-1,-2));
        copyAdbBtn=button("Скопировать ADB-команды");box.addView(copyAdbBtn);copyAdbBtn.setOnClickListener(v->copyAdbCommands());

        TextView h=tv("Режим проверки",19,true);h.setPadding(0,dp(18),0,dp(8));box.addView(h);
        normalBtn=button("5 минут — обычное использование");idleBtn=button("10 минут — простой / экран можно выключить");stopBtn=button("Остановить и сформировать отчёт");stopBtn.setEnabled(false);box.addView(normalBtn);box.addView(idleBtn);box.addView(stopBtn);
        TextView hint=tv("ROOT позволяет получить данные ядра, wakelock и logcat. ADB полезен без root. BASIC даёт ограниченный отчёт. Для оценки батареи тестируй без зарядки при 40–80%. В idle-режиме выключи экран сразу после запуска. Новая версия не исправляет проценты батареи, а собирает данные о причине.",13,false);hint.setTextColor(Color.GRAY);hint.setPadding(0,dp(8),0,dp(16));box.addView(hint);

        TextView rh=tv("Последний результат",19,true);rh.setPadding(0,dp(8),0,dp(8));box.addView(rh);
        result=tv("Результатов пока нет.",14,false);result.setTextIsSelectable(true);result.setPadding(dp(14),dp(14),dp(14),dp(14));result.setBackgroundColor(Color.rgb(245,245,245));box.addView(result,new LinearLayout.LayoutParams(-1,-2));
        saveBtn=button("Сохранить ZIP-отчёт");saveBtn.setPadding(0,dp(14),0,0);box.addView(saveBtn);

        normalBtn.setOnClickListener(v->startDiagnostic(5*60_000L,false));
        idleBtn.setOnClickListener(v->startDiagnostic(10*60_000L,true));
        stopBtn.setOnClickListener(v->{stopBtn.setEnabled(false);prefs().edit().putString("phase","stopping").apply();startService(new Intent(this,DiagnosticService.class).setAction(DiagnosticService.ACTION_STOP));state.setText("Мониторинг остановлен. Формирую отчёт…");updateTimer();});
        saveBtn.setOnClickListener(v->saveLatest());setContentView(scroll);
    }

    private void checkAccess(){
        accessStatus.setText("Доступ: проверяю ROOT/ADB…");
        pool.submit(()->{
            CommandShell.Access a=CommandShell.configure(this);
            main.post(()->{
                String s="Доступ: "+a.details()+"\n"+a.permissionLine();
                if(a.mode==CommandShell.Mode.BASIC)s+="\nДля расширенной диагностики выполни ADB-команды ниже.";
                accessStatus.setText(s);
                if(!isRunning()){normalBtn.setEnabled(true);idleBtn.setEnabled(true);}
            });
        });
    }

    private void copyAdbCommands(){
        ClipboardManager cm=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);if(cm!=null)cm.setPrimaryClip(ClipData.newPlainText("Note 2 Doctor ADB",ADB_COMMANDS));
        Toast.makeText(this,"ADB-команды скопированы",Toast.LENGTH_SHORT).show();
    }

    private void startDiagnostic(long d,boolean idle){
        Intent i=new Intent(this,DiagnosticService.class).setAction(DiagnosticService.ACTION_START).putExtra(DiagnosticService.EXTRA_DURATION,d).putExtra(DiagnosticService.EXTRA_IDLE,idle);
        if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i);
        state.setText(idle?"Idle-тест запущен. Можно выключить экран.":"Диагностика запущена. Пользуйся устройством обычно.");main.postDelayed(this::refreshButtons,500);
    }
    // The activity can be stopped while the screen is off. Completion broadcasts are then
    // missed, so reconcile against durable service state whenever the UI becomes visible
    // and on each timer tick. This also covers a service finishing before registration.
    private void syncStoredState(){
        SharedPreferences p=prefs();
        String saved=p.getString("summary","Результатов пока нет.");
        if(!TextUtils.equals(result.getText(),saved))result.setText(saved);
        boolean running=isRunning();
        String phase=p.getString("phase","idle");
        if(running){
            if("collecting".equals(phase))state.setText("Мониторинг завершён. Собираю системные данные…");
            else if("packing".equals(phase))state.setText("Упаковываю ZIP…");
            else if("stopping".equals(phase))state.setText("Мониторинг остановлен. Формирую отчёт…");
        }else if("idle".equals(phase)){
            String path=p.getString("zip_path","");
            if(!TextUtils.isEmpty(path)&&new File(path).exists())state.setText("Готово. ZIP-отчёт можно сохранить.");
            else if(saved.startsWith("Ошибка диагностики:"))state.setText("Ошибка при создании отчёта.");
        }
        refreshButtons();
    }
    private void refreshButtons(){boolean r=isRunning();String phase=prefs().getString("phase","idle");boolean monitoring=r&&"monitoring".equals(phase);normalBtn.setEnabled(!r);idleBtn.setEnabled(!r);stopBtn.setEnabled(monitoring);String p=prefs().getString("zip_path","");saveBtn.setEnabled(!r&&!TextUtils.isEmpty(p)&&new File(p).exists());updateTimer();}
    private boolean isRunning(){if(!prefs().getBoolean("running",false))return false;long s=prefs().getLong("start_elapsed",0),d=prefs().getLong("duration",0),h=prefs().getLong("heartbeat",0),now=SystemClock.elapsedRealtime();boolean fresh=(s>0&&d>0&&now-s<=d+10*60_000L)||(h>0&&now-h<120_000L);if(!fresh)prefs().edit().putBoolean("running",false).apply();return fresh;}
    private void updateTimer(){if(isRunning()){String phase=prefs().getString("phase","idle");if(!"monitoring".equals(phase)){timer.setText("Мониторинг завершён · отчёт формируется");return;}long start=prefs().getLong("start_elapsed",SystemClock.elapsedRealtime());long dur=prefs().getLong("duration",0),e=Math.max(0,SystemClock.elapsedRealtime()-start),left=Math.max(0,dur-e);timer.setText(String.format(Locale.US,"Таймер: %02d:%02d прошло · %02d:%02d осталось",e/60000,(e/1000)%60,left/60000,(left/1000)%60));}else timer.setText("Таймер: 00:00");}
    private String loadSummary(){return prefs().getString("summary","Результатов пока нет.");}
    private static final int CREATE_REPORT=110;
    private void saveLatest(){
        String p=prefs().getString("zip_path","");
        if(TextUtils.isEmpty(p)||!new File(p).exists()){
            Toast.makeText(this,"Готового ZIP нет",Toast.LENGTH_SHORT).show();return;
        }
        Intent intent=new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/zip");
        intent.putExtra(Intent.EXTRA_TITLE,new File(p).getName());
        try{startActivityForResult(intent,CREATE_REPORT);}
        catch(Exception e){Toast.makeText(this,"Файловый менеджер не поддерживает сохранение: "+e,Toast.LENGTH_LONG).show();}
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode!=CREATE_REPORT||resultCode!=RESULT_OK||data==null||data.getData()==null)return;
        Uri uri=data.getData();String p=prefs().getString("zip_path","");
        pool.submit(()->{
            try(java.io.InputStream in=new java.io.FileInputStream(new File(p));java.io.OutputStream out=getContentResolver().openOutputStream(uri)){
                if(out==null)throw new java.io.IOException("Невозможно открыть документ");
                byte[] buffer=new byte[32768];int n;while((n=in.read(buffer))!=-1)out.write(buffer,0,n);
                main.post(()->Toast.makeText(this,"ZIP сохранён",Toast.LENGTH_LONG).show());
            }catch(Exception e){main.post(()->Toast.makeText(this,"Ошибка ZIP: "+e,Toast.LENGTH_LONG).show());}
        });
    }
    private SharedPreferences prefs(){return getSharedPreferences("state",MODE_PRIVATE);}
    private TextView card(String s){TextView v=tv(s,15,true);v.setPadding(dp(14),dp(12),dp(14),dp(12));v.setBackgroundColor(Color.rgb(242,242,242));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(5),0,dp(5));v.setLayoutParams(lp);return v;}
    private Button button(String s){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setTextSize(15);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(54));lp.setMargins(0,dp(5),0,dp(5));b.setLayoutParams(lp);return b;}
    private TextView tv(String s,int sp,boolean bold){TextView v=new TextView(this);v.setText(s);v.setTextSize(sp);v.setTextColor(Color.rgb(30,30,30));if(bold)v.setTypeface(android.graphics.Typeface.DEFAULT,android.graphics.Typeface.BOLD);return v;}
    private int dp(int v){return(int)(v*getResources().getDisplayMetrics().density+.5f);}
}
