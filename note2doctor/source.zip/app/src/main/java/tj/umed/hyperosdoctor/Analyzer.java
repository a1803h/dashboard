package tj.umed.hyperosdoctor;

import org.json.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public final class Analyzer {
    public static final String SELF="tj.umed.note2doctor.n7100";
    public static final class Agg {
        public final String name; long samples,cpuTicks,rssSumKb; double peakCpu; long peakRssKb; int starts,deaths,crashes,anrs,kills;
        Agg(String n){name=n;}
        double avgCpu(long durationMs){ if(durationMs<=0)return 0; return (cpuTicks*100000.0/ProcSampler.CLK_TCK)/durationMs; }
        double avgRssMb(){return samples==0?0:(rssSumKb/(double)samples)/1024.0;} double peakRssMb(){return peakRssKb/1024.0;}
        double cpuSeconds(){return cpuTicks/(double)ProcSampler.CLK_TCK;}
    }
    private final Map<String,Agg> data=new ConcurrentHashMap<>(); private final boolean idleMode; private final int cores=Math.max(1,Runtime.getRuntime().availableProcessors()); private ProcSampler.Snapshot previous;
    public Analyzer(boolean idle){idleMode=idle;}
    public synchronized void accept(ProcSampler.Snapshot now){
        if(now==null)return; if(previous==null){previous=now;return;} long td=now.totalCpuTicks-previous.totalCpuTicks; if(td<=0){previous=now;return;}
        for(ProcSampler.ProcStat p:now.processes.values()){
            ProcSampler.ProcStat q=previous.processes.get(p.pid); if(q==null||q.startTimeTicks!=p.startTimeTicks||!norm(q.name).equals(norm(p.name)))continue;
            long d=p.cpuTicks-q.cpuTicks; if(d<0)continue; double instant=d*100.0*cores/td; if(instant<0||instant>cores*125.0)continue;
            Agg a=data.computeIfAbsent(norm(p.name),Agg::new); a.samples++; a.cpuTicks+=d; a.peakCpu=Math.max(a.peakCpu,instant); a.rssSumKb+=p.rssKb; a.peakRssKb=Math.max(a.peakRssKb,p.rssKb);
        } previous=now;
    }
    public void eventStart(String p){if(valid(p))data.computeIfAbsent(norm(p),Agg::new).starts++;} public void eventDeath(String p){if(valid(p))data.computeIfAbsent(norm(p),Agg::new).deaths++;}
    public void eventCrash(String p){if(valid(p))data.computeIfAbsent(norm(p),Agg::new).crashes++;} public void eventAnr(String p){if(valid(p))data.computeIfAbsent(norm(p),Agg::new).anrs++;} public void eventKill(String p){if(valid(p))data.computeIfAbsent(norm(p),Agg::new).kills++;}
    public double score(Agg a,long durationMs){ double avg=a.avgCpu(durationMs),s=0; s+=Math.min(42,avg*(idleMode?3.0:1.4)); s+=Math.min(8,a.peakCpu*0.06); s+=Math.min(40,a.crashes*20.0); s+=Math.min(45,a.anrs*30.0); if(a.starts>=4)s+=Math.min(18,(a.starts-3)*3.0); if(a.deaths>=4)s+=Math.min(12,(a.deaths-3)*2.0); if(a.kills>=5)s+=Math.min(8,(a.kills-4)*1.2); if(a.avgRssMb()>1000)s+=Math.min(6,(a.avgRssMb()-1000)/250.0); return Math.min(100,s); }
    public List<Agg> ranked(long durationMs){ List<Agg> l=new ArrayList<>(data.values()); l.removeIf(a->a.name.equals(SELF)||(a.samples<2&&a.crashes==0&&a.anrs==0&&a.starts<2)); l.sort((a,b)->Double.compare(score(b,durationMs),score(a,durationMs))); return l; }
    public Agg self(){return data.get(SELF);}
    public String makeSummary(long durationMs,long requestedMs,long actualMonitorMs,long collectionMs,long uptimeMs,long suspendMs,boolean exactEndAlarm,boolean alarmClockBackup,String accessMode,String stopReason,int earlyTimeoutIgnored,boolean alarmReceived,long alarmLatenessMs,String alarmSource,boolean finalSnapshotUsed){
        StringBuilder sb=new StringBuilder();
        sb.append("Note 2 Doctor — результат\nВерсия: 1.1-note2\nРежим: ").append(idleMode?"простой/экран выключен":"обычное использование").append('\n');
        sb.append("Доступ: ").append(accessMode).append("\n");
        sb.append("Причина завершения: ").append(stopReason).append("\n");
        if(earlyTimeoutIgnored>0)sb.append("Ранних alarm проигнорировано: ").append(earlyTimeoutIgnored).append("\n");
        sb.append(String.format(Locale.US,"Запрошенное окно: %.1f мин\n",requestedMs/60000.0));
        sb.append(String.format(Locale.US,"Окно для расчёта CPU: %.1f мин\n",durationMs/60000.0));
        sb.append(String.format(Locale.US,"Фактический мониторинг: %.1f мин\n",actualMonitorMs/60000.0));
        sb.append(String.format(Locale.US,"Системные дампы после окна: %.1f с\n",collectionMs/1000.0));
        double deep=actualMonitorMs>0?100.0*suspendMs/actualMonitorMs:0;
        sb.append(String.format(Locale.US,"Suspend/deep-sleep estimate: %.1f с (%.1f%%); uptime: %.1f с\n",suspendMs/1000.0,deep,uptimeMs/1000.0));
        sb.append("Exact alarm запланирован: ").append(exactEndAlarm?"YES":"NO/FALLBACK").append("\n");
        sb.append("AlarmClock backup: ").append(alarmClockBackup?"YES":"NO").append("\n");
        if(alarmReceived)sb.append("Alarm окончания принят: ").append(alarmSource).append(String.format(Locale.US,"; lateness %+d мс\n",alarmLatenessMs));
        else sb.append("Alarm окончания принят: NO (цикл завершился сам или вручную)\n");
        sb.append("Финальный process snapshot: ").append(finalSnapshotUsed?"USED":"SKIPPED").append("\n\n");
        List<Agg> l=ranked(durationMs); int n=Math.min(15,l.size()); if(n==0)sb.append("Явных проблемных процессов не найдено.\n");
        for(int i=0;i<n;i++){Agg a=l.get(i);double sc=score(a,durationMs);sb.append(i+1).append(". ").append(a.name).append(" — ").append((int)Math.round(sc)).append("/100"); if(sc>=65)sb.append(" [ПРОБЛЕМА]");else if(sc>=35)sb.append(" [ПОДОЗРИТЕЛЬНО]");sb.append('\n'); sb.append(String.format(Locale.US,"   CPU avg %.2f%% (%.2f с CPU), peak %.1f%%; RAM avg %.0f MB, peak %.0f MB\n",a.avgCpu(durationMs),a.cpuSeconds(),a.peakCpu,a.avgRssMb(),a.peakRssMb())); if(a.crashes+a.anrs+a.starts+a.deaths+a.kills>0)sb.append("   starts ").append(a.starts).append(", deaths ").append(a.deaths).append(", crashes ").append(a.crashes).append(", ANR ").append(a.anrs).append(", kills ").append(a.kills).append('\n'); String why=why(a,durationMs);if(!why.isEmpty())sb.append("   Почему: ").append(why).append('\n'); sb.append('\n');}
        Agg me=self(); if(me!=null)sb.append(String.format(Locale.US,"Нагрузка Note 2 Doctor: %.2f%% avg, %.2f с CPU (из рейтинга исключена).\n",me.avgCpu(durationMs),me.cpuSeconds()));
        sb.append("CPU avg считается только по диагностическому окну; время формирования дампов в знаменатель не входит.\n");
        return sb.toString();
    }
    public JSONObject toJson(long durationMs,long requestedMs,long actualMonitorMs,long collectionMs,long uptimeMs,long suspendMs,boolean exactEndAlarm,boolean alarmClockBackup,String accessMode,String stopReason,int earlyTimeoutIgnored,boolean alarmReceived,long alarmLatenessMs,String alarmSource,boolean finalSnapshotUsed){JSONObject r=new JSONObject();try{r.put("version","1.1-note2");r.put("access_mode",accessMode);r.put("stop_reason",stopReason);r.put("early_timeout_ignored",earlyTimeoutIgnored);r.put("analysis_duration_ms",durationMs);r.put("requested_duration_ms",requestedMs);r.put("actual_monitor_duration_ms",actualMonitorMs);r.put("report_collection_ms",collectionMs);r.put("uptime_delta_ms",uptimeMs);r.put("suspend_estimate_ms",suspendMs);r.put("deep_sleep_estimate_pct",actualMonitorMs>0?round1(100.0*suspendMs/actualMonitorMs):0);r.put("exact_end_alarm",exactEndAlarm);r.put("alarm_clock_backup",alarmClockBackup);r.put("alarm_received",alarmReceived);r.put("alarm_lateness_ms",alarmLatenessMs);r.put("alarm_source",alarmSource);r.put("final_process_snapshot_used",finalSnapshotUsed);r.put("idle_mode",idleMode);r.put("cpu_cores",cores);JSONArray arr=new JSONArray();for(Agg a:ranked(durationMs)){JSONObject o=new JSONObject();o.put("process",a.name);o.put("score",Math.round(score(a,durationMs)));o.put("avg_cpu_pct",round1(a.avgCpu(durationMs)));o.put("cpu_seconds",Math.round(a.cpuSeconds()*1000)/1000.0);o.put("peak_cpu_pct",round1(a.peakCpu));o.put("avg_rss_mb",Math.round(a.avgRssMb()));o.put("peak_rss_mb",Math.round(a.peakRssMb()));o.put("starts",a.starts);o.put("deaths",a.deaths);o.put("crashes",a.crashes);o.put("anrs",a.anrs);o.put("kills",a.kills);o.put("reason",why(a,durationMs));arr.put(o);}r.put("processes",arr);}catch(Exception ignored){}return r;}
    private String why(Agg a,long d){List<String>w=new ArrayList<>();if(a.crashes>0)w.add("crash: "+a.crashes);if(a.anrs>0)w.add("ANR: "+a.anrs);if(a.starts>=5&&a.deaths>=3)w.add("похож на restart-loop");double lim=idleMode?1.5:7.0;if(a.avgCpu(d)>=lim)w.add(String.format(Locale.US,"высокий CPU %.2f%%",a.avgCpu(d)));if(a.peakCpu>=100&&a.cpuSeconds()>3)w.add(String.format(Locale.US,"пики CPU %.0f%%",a.peakCpu));if(a.avgRssMb()>=1200)w.add(String.format(Locale.US,"много RAM ~%.0f MB",a.avgRssMb()));return String.join("; ",w);}
    private static String norm(String s){return s==null?"unknown":s.trim().replace("\u0000","");} private static boolean valid(String s){return s!=null&&!s.trim().isEmpty()&&!s.equals("null");} private static double round1(double x){return Math.round(x*10.0)/10.0;}
}
