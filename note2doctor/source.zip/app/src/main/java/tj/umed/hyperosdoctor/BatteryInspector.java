package tj.umed.hyperosdoctor;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.SystemClock;
import java.io.*;
import java.util.*;

/** Native Android battery broadcast plus raw, read-only fuel-gauge diagnostics. */
public final class BatteryInspector {
    private final Context ctx;
    private final File samples;
    private Integer firstLevel,lastLevel,firstVoltage,lastVoltage;
    private int sampleCount,largestDrop;
    private boolean onCharger;
    public BatteryInspector(Context context,File dir){
        ctx=context.getApplicationContext(); samples=new File(dir,"battery_samples.csv");
        ReportWriter.text(samples,"elapsed_ms,level_pct,scale,voltage_mv,temp_deci_c,plugged,status\n");
    }
    private static int val(Intent i,String key){return i.getIntExtra(key,-1);}
    public void sample(){
        Intent i=ctx.registerReceiver(null,new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if(i==null){ReportWriter.append(samples,SystemClock.elapsedRealtime()+",unavailable\n");return;}
        int lvl=val(i,BatteryManager.EXTRA_LEVEL),scale=val(i,BatteryManager.EXTRA_SCALE);
        int pct=lvl>=0&&scale>0?Math.round(lvl*100f/scale):-1;
        int volt=val(i,BatteryManager.EXTRA_VOLTAGE),temp=val(i,BatteryManager.EXTRA_TEMPERATURE);
        int plug=val(i,BatteryManager.EXTRA_PLUGGED),status=val(i,BatteryManager.EXTRA_STATUS);
        ReportWriter.append(samples,String.format(Locale.US,"%d,%d,%d,%d,%d,%d,%d\n",SystemClock.elapsedRealtime(),pct,scale,volt,temp,plug,status));
        if(firstLevel==null&&pct>=0)firstLevel=pct;
        if(firstVoltage==null&&volt>0)firstVoltage=volt;
        if(lastLevel!=null&&pct>=0)largestDrop=Math.max(largestDrop,lastLevel-pct);
        if(pct>=0)lastLevel=pct;if(volt>0)lastVoltage=volt;
        if(plug>0)onCharger=true;sampleCount++;
    }
    public String summary(){
        StringBuilder b=new StringBuilder("\n=== Battery / fuel-gauge checks ===\n");
        b.append("Samples: ").append(sampleCount).append("; level start/end: ").append(firstLevel).append("% / ").append(lastLevel).append("%; voltage start/end: ").append(firstVoltage).append(" / ").append(lastVoltage).append(" mV.\n");
        if(onCharger)b.append("WARNING: device was charging; cannot evaluate battery drain in this test.\n");
        if(largestDrop>=5)b.append("WARNING: level jumped down by ").append(largestDrop).append(" percentage points between samples. Check raw fuel-gauge logs.\n");
        b.append("capacity, BatteryManager and the status-bar percentage may share ONE kernel driver: agreement is not independent verification.\n");
        b.append("Voltage alone does not determine accurate SOC; compare voltage over time, load and raw/adjusted gauge registers before concluding.\n");
        return b.toString();
    }
    public static String gaugeCommand(){
        return "echo '=== POWER SUPPLY ==='; ls /sys/class/power_supply/ 2>/dev/null; " +
            "echo '=== BATTERY SYSFS (read only) ==='; " +
            "for d in /sys/class/power_supply/battery /sys/class/power_supply/fuelgauge /sys/class/power_supply/max17042-fuelgauge /sys/class/power_supply/max17047-fuelgauge; do " +
            "[ -d \"$d\" ] || continue; echo \"[$d]\"; " +
            "for n in capacity voltage_now current_now temp status health batt_read_raw_soc batt_read_adj_soc batt_vfocv batt_vol_avg batt_vol_adc batt_type fg_capacity fg_voltage_now charge_full charge_counter; do " +
            "[ -r \"$d/$n\" ] && { echo -n \"$n=\"; cat \"$d/$n\" 2>/dev/null; }; " +
            "done; done";
    }
}
