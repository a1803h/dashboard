package tj.umed.hyperosdoctor;

import java.io.*;
import java.nio.charset.StandardCharsets;

public final class EventTracker {
    private final Analyzer analyzer;
    private final File eventsFile,logFile,eventsPostFile,logPostFile;
    private final long windowStartWallMs,windowEndWallMs;
    private volatile boolean running;
    private Process ep,lp;
    private Thread et,lt;
    private int screenOnEvents,screenOffEvents;
    private long analysisLines,postWindowLines;

    public EventTracker(Analyzer a,File dir,long startWallMs,long endWallMs){
        analyzer=a;
        windowStartWallMs=startWallMs;
        windowEndWallMs=endWallMs;
        eventsFile=new File(dir,"logcat_events.txt");
        logFile=new File(dir,"logcat_system.txt");
        eventsPostFile=new File(dir,"logcat_events_post_window.txt");
        logPostFile=new File(dir,"logcat_system_post_window.txt");
    }

    public void start()throws IOException{
        running=true;
        ep=CommandShell.start("exec logcat -b events -v epoch -T 1");
        lp=CommandShell.start("exec logcat -b main -b system -b crash -v epoch -T 1");
        et=pump(ep.getInputStream(),eventsFile,eventsPostFile,true);
        lt=pump(lp.getInputStream(),logFile,logPostFile,false);
    }

    public void stop(){
        running=false;
        if(ep!=null)ep.destroy();if(lp!=null)lp.destroy();
        join(et);join(lt);
        if(ep!=null)ep.destroy();if(lp!=null)lp.destroy();
    }

    public int screenOnEvents(){return screenOnEvents;}
    public int screenOffEvents(){return screenOffEvents;}
    public long analysisLines(){return analysisLines;}
    public long postWindowLines(){return postWindowLines;}

    public String contaminationSummary(boolean idle){
        if(!idle)return "";
        if(screenOnEvents==0)return "Idle-контроль: включений экрана внутри диагностического окна не обнаружено.\n";
        return "ВНИМАНИЕ: экран включался внутри idle-окна "+screenOnEvents+" раз(а). Пики SystemUI/SurfaceFlinger/face/camera в эти моменты не считать фоновым багом.\n";
    }

    private Thread pump(InputStream in,File inWindow,File postWindow,boolean parse){
        Thread t=new Thread(()->{
            try(BufferedReader br=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8));
                BufferedWriter bw=new BufferedWriter(new OutputStreamWriter(new FileOutputStream(inWindow),StandardCharsets.UTF_8));
                BufferedWriter pw=new BufferedWriter(new OutputStreamWriter(new FileOutputStream(postWindow),StandardCharsets.UTF_8))){
                String line;
                while(running&&(line=br.readLine())!=null){
                    long ts=lineEpochMs(line);
                    boolean inside=ts<=0 || (ts>=windowStartWallMs-1500L && ts<=windowEndWallMs+1500L);
                    if(inside){bw.write(line);bw.newLine();analysisLines++;if(parse)parse(line);}
                    else if(ts>windowEndWallMs+1500L){pw.write(line);pw.newLine();postWindowLines++;}
                }
            }catch(Exception ignored){}
        },parse?"events-reader":"logcat-reader");
        t.start();return t;
    }

    private static long lineEpochMs(String line){
        try{
            int sp=line.indexOf(' ');if(sp<=0)return -1;
            double sec=Double.parseDouble(line.substring(0,sp).trim());
            return (long)(sec*1000.0);
        }catch(Exception e){return -1;}
    }

    private void parse(String line){
        if(line.contains(" screen_toggled:")){if(line.trim().endsWith("1"))screenOnEvents++;else if(line.trim().endsWith("0"))screenOffEvents++;}
        int lb=line.lastIndexOf('['),rb=line.lastIndexOf(']');if(lb<0||rb<=lb)return;
        String[] f=line.substring(lb+1,rb).split(",",-1);for(int i=0;i<f.length;i++)f[i]=f[i].trim();
        try{
            if(line.contains(" am_crash:")&&f.length>2)analyzer.eventCrash(f[2]);
            else if(line.contains(" am_anr:")&&f.length>2)analyzer.eventAnr(f[2]);
            else if(line.contains(" am_proc_start:")&&f.length>3)analyzer.eventStart(f[3]);
            else if(line.contains(" am_proc_died:")&&f.length>2)analyzer.eventDeath(f[2]);
            else if((line.contains(" am_kill:")||line.contains(" am_kill :"))&&f.length>2)analyzer.eventKill(f[2]);
        }catch(Exception ignored){}
    }

    private static void join(Thread t){if(t==null)return;try{t.join(1500);}catch(InterruptedException e){Thread.currentThread().interrupt();}}
}
